plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nova.scanner"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nova.scanner"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    signingConfigs {
        create("nova") {
            storeFile = file("nova.jks")
            storePassword = "novascan123"
            keyAlias = "nova"
            keyPassword = "novascan123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("nova")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/INDEX.LIST")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    // document scanner (camera, edge detect, crop, filters)
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0-beta1")
    // OCR (offline, English/Latin)
    implementation("com.google.mlkit:text-recognition:16.0.0")
    // QR / barcode
    implementation("com.google.mlkit:barcode-scanning:17.2.0")
    implementation("com.google.android.gms:play-services-code-scanner:16.0.0")
    // OCR (offline, Bangla + English)
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.8.0")
    // PDF engine: merge, split, edit, text extraction
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // document edge detection + perspective correction
    implementation("org.opencv:opencv:4.9.0")
    // own camera with selectable capture resolution
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
}
