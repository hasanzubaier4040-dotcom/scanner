package com.nova.scanner

import android.content.Context
import android.content.SharedPreferences
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

fun Context.prefs(): SharedPreferences = getSharedPreferences("nova_prefs", Context.MODE_PRIVATE)

fun fmtDate(ms: Long): String =
    SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

fun defaultName(ms: Long): String =
    "Scan " + SimpleDateFormat("dd-MM-yyyy HH.mm", Locale.getDefault()).format(Date(ms))

fun fmtSize(b: Long): String {
    var n = b.toDouble()
    val units = arrayOf("B", "KB", "MB", "GB")
    var i = 0
    while (n >= 1024 && i < units.size - 1) {
        n /= 1024
        i++
    }
    return if (i == 0) String.format(Locale.US, "%.0f %s", n, units[i])
    else String.format(Locale.US, "%.1f %s", n, units[i])
}

fun safeName(s: String): String =
    s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "scan" }
