package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

class OcrResult(val text: String, val blocks: List<Block>)

/** One recognition engine, reused for many pages. engine: 0 ML Kit, 1 Tesseract (Bangla+English), 2 Cloud Vision. */
class OcrRunner(private val ctx: Context, private val engine: Int) {
    private var mlkit: TextRecognizer? = null
    private var tess: TessBaseAPI? = null

    /** Returns an error message, or null when ready. */
    fun prepare(status: (String) -> Unit): String? {
        when (engine) {
            0 -> mlkit = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            1 -> {
                val dir = File(ctx.filesDir, "tess/tessdata")
                for (lang in arrayOf("ben", "eng")) {
                    val f = File(dir, "$lang.traineddata")
                    if (f.exists() && f.length() > 100_000) continue
                    status("Downloading $lang language data (one time)\u2026")
                    val ok = Net.download("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata", f) { pct ->
                        status("Downloading $lang language data\u2026 $pct%")
                    }
                    if (!ok) return "Could not download Bangla language data. Check your internet and try again."
                }
                val t = TessBaseAPI()
                if (!t.init(File(ctx.filesDir, "tess").absolutePath, "ben+eng")) return "Could not start the Bangla engine."
                tess = t
            }
            else -> {
                if (ctx.prefs().getString("vision_key", "").isNullOrBlank()) return "Cloud OCR needs a Google Cloud Vision API key. Choose the engine again to enter it."
            }
        }
        return null
    }

    fun recognize(bmp: Bitmap): OcrResult {
        return when (engine) {
            0 -> mlKit(bmp)
            1 -> {
                val t = tess!!
                t.setImage(bmp)
                val text = (t.getUTF8Text() ?: "").trim()
                OcrResult(text, LayoutAnalyzer.fromPlainText(text))
            }
            else -> CloudOcr.recognize(ctx.prefs().getString("vision_key", "") ?: "", bmp)
        }
    }

    private fun mlKit(bmp: Bitmap): OcrResult {
        val t = Tasks.await(mlkit!!.process(InputImage.fromBitmap(bmp, 0)))
        val k = 595f / max(1, bmp.width)
        val words = ArrayList<WordBox>()
        for (b in t.textBlocks) for (l in b.lines) for (e in l.elements) {
            val r = e.boundingBox ?: continue
            words.add(
                WordBox(e.text, r.left * k, r.top * k, r.right * k, r.bottom * k, max(5f, r.height() * k / 1.15f), false, false)
            )
        }
        val blocks = LayoutAnalyzer.analyze(PageText(595f, bmp.height * k, words))
        val text = t.textBlocks.joinToString("\n\n") { b -> b.lines.joinToString("\n") { it.text } }
        return OcrResult(text, blocks)
    }

    fun close() {
        try {
            tess?.recycle()
            mlkit?.close()
        } catch (e: Exception) {
            // ignore
        }
    }
}

/** Online OCR (handwriting, Bangla, layout) through Google Cloud Vision. Needs the user's own API key. */
object CloudOcr {
    fun recognize(key: String, bmp: Bitmap): OcrResult {
        var b = bmp
        val longest = max(b.width, b.height)
        if (longest > 2400) {
            val f = 2400f / longest
            b = Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
        }
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 88, bos)
        val sentW = b.width
        val sentH = b.height
        if (b !== bmp) b.recycle()
        val body = JSONObject()
            .put(
                "requests", org.json.JSONArray().put(
                    JSONObject()
                        .put("image", JSONObject().put("content", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)))
                        .put("features", org.json.JSONArray().put(JSONObject().put("type", "DOCUMENT_TEXT_DETECTION")))
                        .put("imageContext", JSONObject().put("languageHints", org.json.JSONArray().put("bn").put("en")))
                )
            ).toString()
        val c = URL("https://vision.googleapis.com/v1/images:annotate?key=" + key.trim()).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(resp).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                "HTTP $code"
            }
            throw IllegalStateException("Cloud OCR: $msg")
        }
        val r0 = JSONObject(resp).getJSONArray("responses").getJSONObject(0)
        if (r0.has("error")) throw IllegalStateException("Cloud OCR: " + r0.getJSONObject("error").optString("message"))
        val full = r0.optJSONObject("fullTextAnnotation") ?: return OcrResult("", emptyList())
        val text = full.optString("text", "").trim()
        val k = 595f / max(1, sentW)
        val words = ArrayList<WordBox>()
        val pages = full.optJSONArray("pages")
        if (pages != null) for (pi in 0 until pages.length()) {
            val blocks = pages.getJSONObject(pi).optJSONArray("blocks") ?: continue
            for (bi in 0 until blocks.length()) {
                val paras = blocks.getJSONObject(bi).optJSONArray("paragraphs") ?: continue
                for (pa in 0 until paras.length()) {
                    val ws = paras.getJSONObject(pa).optJSONArray("words") ?: continue
                    for (wi in 0 until ws.length()) {
                        val w = ws.getJSONObject(wi)
                        val syms = w.optJSONArray("symbols") ?: continue
                        val sb = StringBuilder()
                        for (si in 0 until syms.length()) sb.append(syms.getJSONObject(si).optString("text", ""))
                        val vs = w.optJSONObject("boundingBox")?.optJSONArray("vertices") ?: continue
                        if (vs.length() < 4) continue
                        var x0 = Int.MAX_VALUE
                        var y0 = Int.MAX_VALUE
                        var x1 = 0
                        var y1 = 0
                        for (vi in 0 until vs.length()) {
                            val v = vs.getJSONObject(vi)
                            val x = v.optInt("x", 0)
                            val y = v.optInt("y", 0)
                            if (x < x0) x0 = x
                            if (y < y0) y0 = y
                            if (x > x1) x1 = x
                            if (y > y1) y1 = y
                        }
                        words.add(WordBox(sb.toString(), x0 * k, y0 * k, x1 * k, y1 * k, max(5f, (y1 - y0) * k / 1.15f), false, false))
                    }
                }
            }
        }
        val blocks = if (words.isEmpty()) LayoutAnalyzer.fromPlainText(text) else LayoutAnalyzer.analyze(PageText(595f, sentH * k, words))
        return OcrResult(text, blocks)
    }
}
