package com.nova.scanner

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class LibRow(val folder: String?, val scan: Scan?, val title: String, val sub: String)

class LibraryActivity : AppCompatActivity() {

    private val rows = ArrayList<LibRow>()
    private lateinit var adapter: LibAdapter
    private lateinit var titleView: TextView
    private lateinit var search: EditText
    private lateinit var empty: TextView
    private lateinit var newFolderBtn: TextView
    private var currentFolder: String? = null
    private var sortMode = 0 // 0 newest, 1 name, 2 size, 3 pages

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            currentFolder = null
            isEnabled = false
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sortMode = prefs().getInt("lib_sort", 0)
        onBackPressedDispatcher.addCallback(this, backCb)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val (header, tv) = headerRow("My Documents") { onBackPressedDispatcher.onBackPressed() }
        titleView = tv
        header.addView(iconBtn("\u21C5") { sortDialog() })
        newFolderBtn = iconBtn("\uD83D\uDCC1") {
            Actions.newFolder(this) { refresh() }
        }
        header.addView(newFolderBtn)
        root.addView(header)

        search = EditText(this)
        search.hint = "Search documents"
        search.setHintTextColor(GRAY)
        search.setTextColor(Color.WHITE)
        search.textSize = 15f
        search.maxLines = 1
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.setPadding(dp(14), dp(10), dp(14), dp(10))
        search.background = roundBg(CARD, 10)
        search.doAfterTextChanged { refresh() }
        val sp = LinearLayout.LayoutParams(MATCH, WRAP)
        sp.setMargins(dp(16), dp(4), dp(16), dp(8))
        root.addView(search, sp)

        val frame = FrameLayout(this)
        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = LibAdapter(rows, { onRow(it) }, { onRowLong(it) })
        rv.adapter = adapter
        frame.addView(rv, FrameLayout.LayoutParams(MATCH, MATCH))
        empty = TextView(this)
        empty.setTextColor(GRAY)
        empty.textSize = 16f
        empty.gravity = Gravity.CENTER
        empty.visibility = View.GONE
        frame.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun refresh() {
        val q = search.text.toString().trim().lowercase()
        val all = ScanStore.list(this)
        val cmp: Comparator<Scan> = when (sortMode) {
            1 -> Comparator { a, b -> a.name.compareTo(b.name, true) }
            2 -> Comparator { a, b -> b.sizeBytes.compareTo(a.sizeBytes) }
            3 -> Comparator { a, b -> b.pages.size.compareTo(a.pages.size) }
            else -> Comparator { a, b -> b.id.compareTo(a.id) }
        }
        rows.clear()
        val folder = currentFolder
        if (q.isNotEmpty()) {
            all.filter { it.name.lowercase().contains(q) }.sortedWith(cmp).forEach { rows.add(scanRow(it, true)) }
        } else if (folder == null) {
            for (f in Folders.list(this)) {
                val n = all.count { it.folder == f }
                rows.add(LibRow(f, null, f, "$n document" + (if (n == 1) "" else "s")))
            }
            all.filter { it.folder.isEmpty() }.sortedWith(cmp).forEach { rows.add(scanRow(it, false)) }
        } else {
            all.filter { it.folder == folder }.sortedWith(cmp).forEach { rows.add(scanRow(it, false)) }
        }
        adapter.notifyDataSetChanged()
        titleView.text = folder ?: "My Documents"
        newFolderBtn.visibility = if (folder == null) View.VISIBLE else View.GONE
        backCb.isEnabled = folder != null
        if (rows.isEmpty()) {
            empty.text = if (q.isNotEmpty()) "No matching documents" else "No documents here yet"
            empty.visibility = View.VISIBLE
        } else {
            empty.visibility = View.GONE
        }
    }

    private fun scanRow(s: Scan, showFolder: Boolean): LibRow {
        val n = s.pageCount
        val sub = "$n page" + (if (n == 1) "" else "s") + "  \u2022  " + fmtSize(s.sizeBytes) +
            "  \u2022  " + fmtDate(s.id) +
            (if (showFolder && s.folder.isNotEmpty()) "  \u2022  \uD83D\uDCC1 " + s.folder else "")
        return LibRow(null, s, s.name, sub)
    }

    private fun onRow(r: LibRow) {
        if (r.folder != null) {
            currentFolder = r.folder
            search.setText("")
            refresh()
        } else {
            r.scan?.let {
                if (it.pdfOnly) {
                    startActivity(Intent(this, ReaderActivity::class.java).putExtra("path", it.pdf?.absolutePath).putExtra("title", it.name))
                } else {
                    startActivity(Intent(this, DetailActivity::class.java).putExtra("id", it.id))
                }
            }
        }
    }

    private fun onRowLong(r: LibRow) {
        val f = r.folder
        if (f != null) {
            AlertDialog.Builder(this)
                .setTitle(f)
                .setItems(arrayOf("Open", "Rename folder", "Delete folder")) { _, i ->
                    when (i) {
                        0 -> onRow(r)
                        1 -> Actions.renameFolder(this, f) { refresh() }
                        2 -> Actions.deleteFolder(this, f) { refresh() }
                    }
                }
                .show()
            return
        }
        val s = r.scan ?: return
        AlertDialog.Builder(this)
            .setTitle(s.name)
            .setItems(arrayOf("Open", "Share", "Rename", "Move to folder", "Delete")) { _, i ->
                when (i) {
                    0 -> onRow(r)
                    1 -> Actions.shareDialog(this, s)
                    2 -> Actions.rename(this, s) { refresh() }
                    3 -> Actions.move(this, s) { refresh() }
                    4 -> Actions.delete(this, s) { refresh() }
                }
            }
            .show()
    }

    private fun sortDialog() {
        chooseDialog("Sort by", arrayOf("Newest first", "Name", "Size (largest)", "Pages (most)"), sortMode) {
            sortMode = it
            prefs().edit().putInt("lib_sort", it).apply()
            refresh()
        }
    }
}

class LibAdapter(
    private val items: List<LibRow>,
    private val onClick: (LibRow) -> Unit,
    private val onLong: (LibRow) -> Unit
) : RecyclerView.Adapter<LibAdapter.VH>() {

    class VH(
        val root: LinearLayout,
        val thumb: ImageView,
        val icon: TextView,
        val title: TextView,
        val sub: TextView
    ) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val root = LinearLayout(c)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(c.dp(14), c.dp(8), c.dp(14), c.dp(8))
        root.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)

        val frame = FrameLayout(c)
        val thumb = ImageView(c)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.setBackgroundColor(Color.parseColor("#262626"))
        frame.addView(thumb, FrameLayout.LayoutParams(c.dp(66), c.dp(86)))
        val icon = TextView(c)
        icon.text = "\uD83D\uDCC1"
        icon.textSize = 30f
        icon.gravity = Gravity.CENTER
        icon.visibility = View.GONE
        frame.addView(icon, FrameLayout.LayoutParams(c.dp(66), c.dp(86)))
        root.addView(frame, LinearLayout.LayoutParams(c.dp(66), c.dp(86)))

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(c.dp(14), 0, 0, 0)
        val title = TextView(c)
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        val sub = TextView(c)
        sub.setTextColor(GRAY)
        sub.textSize = 12f
        sub.setPadding(0, c.dp(4), 0, 0)
        col.addView(title)
        col.addView(sub)
        root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        return VH(root, thumb, icon, title, sub)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        h.title.text = r.title
        h.sub.text = r.sub
        val first = r.scan?.previewFile
        if (r.folder != null) {
            h.thumb.tag = null
            h.thumb.setImageDrawable(null)
            h.icon.visibility = View.VISIBLE
        } else {
            h.icon.visibility = View.GONE
            if (first != null) Thumbs.load(h.root.context, first, h.thumb, 300) else h.thumb.setImageDrawable(null)
        }
        h.root.setOnClickListener { onClick(r) }
        h.root.setOnLongClickListener {
            onLong(r)
            true
        }
    }
}
