package com.nova.scanner

import android.app.Application

class NovaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PdfCore.init(this)
    }
}
