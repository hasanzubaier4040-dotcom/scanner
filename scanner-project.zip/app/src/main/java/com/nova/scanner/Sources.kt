package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlin.math.max

/** One page to process: an image, or one page of a PDF. */
class PageJob(val uri: Uri, val pdfPage: Int, val label: String)

object Sources {
    fun isPdf(ctx: Context, uri: Uri): Boolean {
        val t = try {
            ctx.contentResolver.getType(uri)
        } catch (e: Exception) {
            null
        }
        if (t == "application/pdf") return true
        return (uri.lastPathSegment ?: "").lowercase().endsWith(".pdf")
    }

    fun expand(ctx: Context, uris: List<Uri>): List<PageJob> {
        val jobs = ArrayList<PageJob>()
        var imgNo = 0
        for (u in uris) {
            if (isPdf(ctx, u)) {
                var pfd: ParcelFileDescriptor? = null
                var r: PdfRenderer? = null
                try {
                    pfd = ctx.contentResolver.openFileDescriptor(u, "r")
                    if (pfd != null) {
                        r = PdfRenderer(pfd)
                        for (p in 0 until r.pageCount) jobs.add(PageJob(u, p, "PDF page ${p + 1}"))
                    }
                } catch (e: Exception) {
                    // unreadable / protected PDF: skip
                } finally {
                    try {
                        r?.close()
                        pfd?.close()
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            } else {
                imgNo++
                jobs.add(PageJob(u, -1, "Image $imgNo"))
            }
        }
        return jobs
    }

    fun fromScan(s: Scan): List<PageJob> =
        s.pages.mapIndexed { i, f -> PageJob(Uri.fromFile(f), -1, "Page ${i + 1}") }

    class Loader(private val ctx: Context) {
        private val open = HashMap<Uri, Pair<PdfRenderer, ParcelFileDescriptor>>()

        fun bitmap(job: PageJob, maxLong: Int): Bitmap? {
            try {
                if (job.pdfPage < 0) return ImageUtil.decode(ctx, job.uri, maxLong)
                var pair = open[job.uri]
                if (pair == null) {
                    val pfd = ctx.contentResolver.openFileDescriptor(job.uri, "r") ?: return null
                    pair = Pair(PdfRenderer(pfd), pfd)
                    open[job.uri] = pair
                }
                val page = pair.first.openPage(job.pdfPage)
                try {
                    val s = maxLong.toFloat() / max(page.width, page.height)
                    val w = max(1, (page.width * s).toInt())
                    val h = max(1, (page.height * s).toInt())
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bmp
                } finally {
                    page.close()
                }
            } catch (e: Exception) {
                return null
            } catch (e: OutOfMemoryError) {
                return null
            }
        }

        fun close() {
            for (p in open.values) {
                try {
                    p.first.close()
                    p.second.close()
                } catch (e: Exception) {
                    // ignore
                }
            }
            open.clear()
        }
    }
}
