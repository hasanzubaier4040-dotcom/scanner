package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max
import kotlin.math.sqrt

/** Image resolution + max file size presets, applied when exporting / converting. */
object Quality {
    val resLabels = arrayOf("Original (max 5000 px)", "4096 \u00D7 3072", "3264 \u00D7 2448", "1440 \u00D7 1080", "1280 \u00D7 960")
    private val resLong = intArrayOf(5000, 4096, 3264, 1440, 1280)
    private val resShort = intArrayOf(3750, 3072, 2448, 1080, 960)
    val camLabels = arrayOf("Maximum (device best)", "4096 \u00D7 3072", "3264 \u00D7 2448", "1440 \u00D7 1080", "1280 \u00D7 960")
    val camW = intArrayOf(0, 4096, 3264, 1440, 1280)
    val camH = intArrayOf(0, 3072, 2448, 1080, 960)
    val sizeLabels = arrayOf("No limit", "2 MB", "4 MB", "8 MB", "16 MB")
    private val sizeMB = intArrayOf(0, 2, 4, 8, 16)

    fun resIndex(ctx: Context): Int = ctx.prefs().getInt("q_res", 0).coerceIn(0, resLabels.size - 1)
    fun sizeIndex(ctx: Context): Int = ctx.prefs().getInt("q_size", 0).coerceIn(0, sizeLabels.size - 1)
    fun camIndex(ctx: Context): Int = ctx.prefs().getInt("q_cam", 1).coerceIn(0, camLabels.size - 1)
    fun resLongOf(i: Int): Int = resLong[i]
    fun resShortOf(i: Int): Int = resShort[i]
    fun isOriginal(ctx: Context): Boolean = resIndex(ctx) == 0 && sizeIndex(ctx) == 0

    fun summary(ctx: Context): String {
        if (isOriginal(ctx)) return "Original"
        val r = if (resIndex(ctx) == 0) "Original px" else resLabels[resIndex(ctx)]
        val s = if (sizeIndex(ctx) == 0) "" else " \u2264 " + sizeLabels[sizeIndex(ctx)]
        return r + s
    }

    fun budgetPerPage(ctx: Context, pages: Int): Long {
        val mb = sizeMB[sizeIndex(ctx)]
        if (mb == 0) return Long.MAX_VALUE
        return max(30_000L, (mb * 1024L * 1024L - 30_000L) / max(1, pages))
    }

    fun fullSummary(ctx: Context): String =
        "Camera " + camLabels[camIndex(ctx)].replace(" (device best)", "") + "  \u2192  Output " + summary(ctx)

    fun showDialog(a: AppCompatActivity, showCamera: Boolean = false, onDone: () -> Unit) {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(a.dp(20), a.dp(12), a.dp(20), a.dp(4))
        fun label(t: String): TextView {
            val tv = TextView(a)
            tv.text = t
            tv.textSize = 13f
            tv.setPadding(0, a.dp(10), 0, 0)
            return tv
        }
        val s1 = Spinner(a)
        s1.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, resLabels)
        s1.setSelection(resIndex(a))
        val s2 = Spinner(a)
        s2.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, sizeLabels)
        s2.setSelection(sizeIndex(a))
        val s0 = Spinner(a)
        s0.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, camLabels)
        s0.setSelection(camIndex(a))
        if (showCamera) {
            box.addView(label("Camera capture resolution (before scanning)"))
            box.addView(s0)
        }
        box.addView(label("Output resolution (never upscaled)"))
        box.addView(s1)
        box.addView(label("Maximum file size (whole PDF)"))
        box.addView(s2)
        AlertDialog.Builder(a)
            .setTitle("Quality")
            .setView(box)
            .setPositiveButton("Apply") { _, _ ->
                val ed = a.prefs().edit().putInt("q_res", s1.selectedItemPosition).putInt("q_size", s2.selectedItemPosition)
                if (showCamera) ed.putInt("q_cam", s0.selectedItemPosition)
                ed.apply()
                onDone()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun jpeg(bmp: Bitmap, q: Int): ByteArray {
        val b = ByteArrayOutputStream(max(32 * 1024, bmp.width * bmp.height / 8))
        bmp.compress(Bitmap.CompressFormat.JPEG, q, b)
        return b.toByteArray()
    }

    /** Encode [src] as JPEG that fits [budget] bytes (lowers quality, then size). Does not recycle [src]. */
    fun encodeWithin(src: Bitmap, budget: Long): EncodedPage {
        if (budget == Long.MAX_VALUE) return EncodedPage(jpeg(src, 90), src.width, src.height)
        var bmp = src
        for (round in 0 until 4) {
            var lo = 35
            var hi = 92
            var best: ByteArray? = null
            while (lo <= hi) {
                val mid = (lo + hi) / 2
                val d = jpeg(bmp, mid)
                if (d.size <= budget) {
                    best = d
                    lo = mid + 1
                } else {
                    hi = mid - 1
                }
            }
            if (best != null) {
                val r = EncodedPage(best, bmp.width, bmp.height)
                if (bmp !== src) bmp.recycle()
                return r
            }
            val low = jpeg(bmp, 35).size.toDouble()
            val f = (sqrt(budget / low) * 0.92).coerceIn(0.25, 0.95)
            val nb = Bitmap.createScaledBitmap(
                bmp, max(1, (bmp.width * f).toInt()), max(1, (bmp.height * f).toInt()), true
            )
            if (bmp !== src) bmp.recycle()
            bmp = nb
        }
        val r = EncodedPage(jpeg(bmp, 35), bmp.width, bmp.height)
        if (bmp !== src) bmp.recycle()
        return r
    }

    /** Scale [bmp] to fit the chosen output resolution, then encode within [budget]. Does not recycle [bmp]. */
    fun encodeBitmapScaled(bmp: Bitmap, resIdx: Int, budget: Long): EncodedPage {
        val longest = max(bmp.width, bmp.height).toFloat()
        val shortest = kotlin.math.min(bmp.width, bmp.height).toFloat()
        val scale = kotlin.math.min(1f, kotlin.math.min(resLong[resIdx] / longest, resShort[resIdx] / shortest))
        if (scale >= 0.999f) return encodeWithin(bmp, budget)
        val sc = Bitmap.createScaledBitmap(bmp, max(1, (bmp.width * scale).toInt()), max(1, (bmp.height * scale).toInt()), true)
        return try {
            encodeWithin(sc, budget)
        } finally {
            if (sc !== bmp) sc.recycle()
        }
    }

    fun encodeUri(ctx: Context, uri: Uri, extraRot: Int, resIdx: Int, budget: Long): EncodedPage? {
        val bmp = ImageUtil.decode(ctx, uri, resLong[resIdx], resShort[resIdx], extraRot) ?: return null
        return try {
            encodeWithin(bmp, budget)
        } catch (e: OutOfMemoryError) {
            null
        } finally {
            bmp.recycle()
        }
    }
}

/** Builds share/save-ready files (nice names, current quality) in the cache folder. */
object Exporter {
    private fun dirFor(ctx: Context, s: Scan): File = File(ctx.cacheDir, "export/${s.id}").also { it.mkdirs() }

    fun clearCache(ctx: Context) {
        File(ctx.cacheDir, "export").deleteRecursively()
    }

    fun pdf(ctx: Context, s: Scan, progress: (String) -> Unit): File? {
        val out = File(dirFor(ctx, s), safeName(s.name) + ".pdf")
        val orig = s.pdf
        if (Quality.isOriginal(ctx) && orig != null) {
            orig.copyTo(out, overwrite = true)
            return out
        }
        val n = s.pages.size
        if (n == 0) return orig
        val budget = Quality.budgetPerPage(ctx, n)
        val enc = ArrayList<EncodedPage>()
        s.pages.forEachIndexed { i, f ->
            progress("Optimizing page ${i + 1}/$n\u2026")
            Quality.encodeUri(ctx, Uri.fromFile(f), 0, Quality.resIndex(ctx), budget)?.let { enc.add(it) }
        }
        if (enc.isEmpty()) return null
        return if (MiniPdf.writeSpecs(out, MiniPdf.layout(enc, PdfLayout(0f, 0f, 0f, 0)))) out else null
    }

    fun images(ctx: Context, s: Scan, progress: (String) -> Unit): List<File> {
        val dir = dirFor(ctx, s)
        val base = safeName(s.name)
        val n = s.pages.size
        val out = ArrayList<File>()
        if (Quality.isOriginal(ctx)) {
            s.pages.forEachIndexed { i, f ->
                val o = File(dir, "${base}_${i + 1}.jpg")
                f.copyTo(o, overwrite = true)
                out.add(o)
            }
            return out
        }
        val budget = if (Quality.sizeIndex(ctx) == 0) Long.MAX_VALUE else Quality.budgetPerPage(ctx, n)
        s.pages.forEachIndexed { i, f ->
            progress("Optimizing image ${i + 1}/$n\u2026")
            val e = Quality.encodeUri(ctx, Uri.fromFile(f), 0, Quality.resIndex(ctx), budget)
            if (e != null) {
                val o = File(dir, "${base}_${i + 1}.jpg")
                o.writeBytes(e.jpeg)
                out.add(o)
            }
        }
        return out
    }
}
