package com.nova.scanner

import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class WordBox(
    val text: String,
    val x0: Float, val y0: Float, val x1: Float, val y1: Float,
    val size: Float, val bold: Boolean, val italic: Boolean
)

class PageText(val width: Float, val height: Float, val words: List<WordBox>)

class Run(val text: String, val bold: Boolean, val italic: Boolean, val size: Float)

sealed class Block {
    class Para(val runs: List<Run>, val align: Int, val heading: Boolean) : Block() {
        val text: String get() = runs.joinToString("") { it.text }
    }

    class Table(val rows: List<List<String>>) : Block()
    class Img(val jpeg: ByteArray, val w: Int, val h: Int, val widthPt: Float) : Block()
}

fun xesc(s: String): String {
    val sb = StringBuilder(s.length + 16)
    for (ch in s) {
        when {
            ch == '&' -> sb.append("&amp;")
            ch == '<' -> sb.append("&lt;")
            ch == '>' -> sb.append("&gt;")
            ch == '"' -> sb.append("&quot;")
            ch == '\t' || ch == '\n' || ch.code >= 0x20 -> sb.append(ch)
        }
    }
    return sb.toString()
}

/** Turns positioned words (from a PDF or from OCR) into paragraphs and tables. */
object LayoutAnalyzer {
    private class Cell(val text: String, val x0: Float, val x1: Float)

    private class Line(val words: List<WordBox>) {
        val x0: Float = words.minOf { it.x0 }
        val x1: Float = words.maxOf { it.x1 }
        val y0: Float = words.minOf { it.y0 }
        val y1: Float = words.maxOf { it.y1 }
        val size: Float = words.map { it.size }.average().toFloat()
    }

    private val listRx = Regex("^([\\u2022\\u00B7\\u25AA\\u25CF\\-\\u2013*]|\\d{1,3}[.)]|[a-zA-Z][.)])$")

    fun analyze(page: PageText): List<Block> {
        if (page.words.isEmpty()) return emptyList()
        val lines = buildLines(page.words)
        val sizes = lines.map { it.size }.sorted()
        val median = sizes[sizes.size / 2]
        val cells = lines.map { splitCells(it) }
        val out = ArrayList<Block>()
        val para = ArrayList<Line>()

        fun flush() {
            if (para.isNotEmpty()) {
                out.add(makePara(para, page, median))
                para.clear()
            }
        }

        var i = 0
        while (i < lines.size) {
            if (cells[i].size >= 2) {
                var j = i
                while (j + 1 < lines.size && cells[j + 1].size >= 2 &&
                    lines[j + 1].y0 - lines[j].y1 < lines[j].size * 1.3f
                ) j++
                if (j > i) {
                    val t = makeTable(cells.subList(i, j + 1))
                    if (t != null) {
                        flush()
                        out.add(t)
                        i = j + 1
                        continue
                    }
                }
            }
            val l = lines[i]
            val prev = para.lastOrNull()
            if (prev != null) {
                val gap = l.y0 - prev.y1
                if (gap > prev.size * 0.9f || abs(l.size - prev.size) > 1.5f || isListStart(l)) flush()
            }
            para.add(l)
            i++
        }
        flush()
        return out
    }

    private fun buildLines(words: List<WordBox>): List<Line> {
        val sorted = words.sortedBy { (it.y0 + it.y1) / 2f }
        val groups = ArrayList<MutableList<WordBox>>()
        for (w in sorted) {
            val g = groups.lastOrNull()
            if (g != null) {
                val gcy = g.map { (it.y0 + it.y1) / 2f }.average().toFloat()
                val h = max(max(1f, w.y1 - w.y0), g[0].y1 - g[0].y0)
                if (abs((w.y0 + w.y1) / 2f - gcy) < 0.55f * h) {
                    g.add(w)
                    continue
                }
            }
            groups.add(mutableListOf(w))
        }
        return groups.map { g -> Line(g.sortedBy { it.x0 }) }
    }

    private fun splitCells(line: Line): List<Cell> {
        val out = ArrayList<Cell>()
        val gapMin = max(line.size * 1.2f, 6f)
        var text = StringBuilder()
        var cx0 = line.words[0].x0
        var prev: WordBox? = null
        for (w in line.words) {
            if (prev != null && w.x0 - prev.x1 > gapMin) {
                out.add(Cell(text.toString(), cx0, prev.x1))
                text = StringBuilder()
                cx0 = w.x0
            }
            if (text.isNotEmpty()) text.append(' ')
            text.append(w.text)
            prev = w
        }
        out.add(Cell(text.toString(), cx0, prev?.x1 ?: cx0))
        return out
    }

    private fun makeTable(rows: List<List<Cell>>): Block.Table? {
        val xs = rows.flatMap { r -> r.map { it.x0 } }.sorted()
        val cols = ArrayList<Float>()
        var groupStart = xs[0]
        var sum = 0f
        var cnt = 0
        for (x in xs) {
            if (x - groupStart > 8f) {
                cols.add(sum / cnt)
                groupStart = x
                sum = 0f
                cnt = 0
            }
            sum += x
            cnt++
        }
        cols.add(sum / cnt)
        if (cols.size < 2) return null
        val table = ArrayList<List<String>>()
        for (r in rows) {
            val arr = Array(cols.size) { "" }
            for (c in r) {
                var idx = 0
                for (k in cols.indices) if (cols[k] <= c.x0 + 8f) idx = k
                arr[idx] = if (arr[idx].isEmpty()) c.text else arr[idx] + " " + c.text
            }
            table.add(arr.toList())
        }
        return Block.Table(table)
    }

    private fun isListStart(l: Line): Boolean = listRx.matches(l.words[0].text)

    private fun makePara(lines: List<Line>, page: PageText, median: Float): Block.Para {
        val first = lines[0]
        val heading = first.size >= median * 1.25f && lines.size <= 4
        val cx = (first.x0 + first.x1) / 2f
        val align = when {
            abs(cx - page.width / 2f) < page.width * 0.04f && first.x0 > page.width * 0.12f -> 1
            first.x0 > page.width * 0.55f && first.x1 > page.width * 0.85f -> 2
            else -> 0
        }
        val runs = ArrayList<Run>()
        var firstWord = true
        for (line in lines) {
            for (w in line.words) {
                val txt = if (firstWord) w.text else " " + w.text
                firstWord = false
                val sz = (w.size * 2f).roundToInt() / 2f
                val bold = w.bold || heading
                val last = runs.lastOrNull()
                if (last != null && last.bold == bold && last.italic == w.italic && abs(last.size - sz) < 0.6f) {
                    runs[runs.size - 1] = Run(last.text + txt, bold, w.italic, last.size)
                } else {
                    runs.add(Run(txt, bold, w.italic, sz))
                }
            }
        }
        return Block.Para(runs, align, heading)
    }

    /** Plain text -> paragraphs (used for Tesseract output). */
    fun fromPlainText(text: String): List<Block> {
        val out = ArrayList<Block>()
        for (p in text.replace("\r\n", "\n").split(Regex("\\n\\s*\\n"))) {
            val t = p.trim()
            if (t.isNotEmpty()) out.add(Block.Para(listOf(Run(t.replace("\n", " "), false, false, 11f)), 0, false))
        }
        return out
    }
}

/** Real .docx with paragraphs, formatting, tables and images. */
object DocxBlocks {
    private fun twip(pt: Float) = (pt * 20f).roundToInt()

    fun write(out: File, pages: List<List<Block>>): Boolean {
        return try {
            val body = StringBuilder()
            val media = ArrayList<ByteArray>()
            val rels = StringBuilder()
            var docPrId = 1
            pages.forEachIndexed { pi, blocks ->
                if (pi > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
                for (b in blocks) {
                    when (b) {
                        is Block.Para -> body.append(para(b))
                        is Block.Table -> body.append(table(b))
                        is Block.Img -> {
                            media.add(b.jpeg)
                            val n = media.size
                            rels.append("<Relationship Id=\"rIdImg$n\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image$n.jpg\"/>")
                            val wPt = min(b.widthPt, 450f)
                            val hPt = wPt * b.h / max(1, b.w)
                            val cx = (wPt * 12700f).toLong()
                            val cy = (hPt * 12700f).toLong()
                            body.append(
                                "<w:p><w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
                                    "<wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:docPr id=\"${docPrId++}\" name=\"Picture $n\"/>" +
                                    "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                                    "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"0\" name=\"image$n.jpg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                                    "<pic:blipFill><a:blip r:embed=\"rIdImg$n\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                                    "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm>" +
                                    "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
                                    "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"
                            )
                        }
                    }
                }
            }
            val document = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
                "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>" + body +
                "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
                "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>" +
                "</w:sectPr></w:body></w:document>"
            val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
                "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                "</Types>"
            val rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                "</Relationships>"
            val docRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" + rels + "</Relationships>"
            ZipOutputStream(FileOutputStream(out)).use { z ->
                fun put(name: String, data: ByteArray) {
                    z.putNextEntry(ZipEntry(name))
                    z.write(data)
                    z.closeEntry()
                }
                put("[Content_Types].xml", types.toByteArray(Charsets.UTF_8))
                put("_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
                put("word/document.xml", document.toByteArray(Charsets.UTF_8))
                put("word/_rels/document.xml.rels", docRels.toByteArray(Charsets.UTF_8))
                media.forEachIndexed { i, d -> put("word/media/image${i + 1}.jpg", d) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun runXml(r: Run, forceBold: Boolean): String {
        val sz = max(2, (r.size * 2f).roundToInt())
        val rpr = "<w:rPr><w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:cs=\"Nirmala UI\"/>" +
            (if (r.bold || forceBold) "<w:b/>" else "") + (if (r.italic) "<w:i/>" else "") +
            "<w:sz w:val=\"$sz\"/><w:szCs w:val=\"$sz\"/></w:rPr>"
        return "<w:r>$rpr<w:t xml:space=\"preserve\">${xesc(r.text)}</w:t></w:r>"
    }

    private fun para(p: Block.Para): String {
        val jc = when (p.align) {
            1 -> "<w:jc w:val=\"center\"/>"
            2 -> "<w:jc w:val=\"right\"/>"
            else -> ""
        }
        val sb = StringBuilder("<w:p><w:pPr><w:spacing w:after=\"${if (p.heading) 160 else 100}\"/>$jc</w:pPr>")
        for (r in p.runs) sb.append(runXml(r, p.heading))
        sb.append("</w:p>")
        return sb.toString()
    }

    private fun table(t: Block.Table): String {
        val cols = t.rows.maxOf { it.size }
        val w = 9638 / max(1, cols)
        val border = { n: String -> "<w:$n w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"808080\"/>" }
        val sb = StringBuilder("<w:tbl><w:tblPr><w:tblW w:w=\"0\" w:type=\"auto\"/><w:tblBorders>")
        for (n in arrayOf("top", "left", "bottom", "right", "insideH", "insideV")) sb.append(border(n))
        sb.append("</w:tblBorders></w:tblPr><w:tblGrid>")
        for (c in 0 until cols) sb.append("<w:gridCol w:w=\"$w\"/>")
        sb.append("</w:tblGrid>")
        for (row in t.rows) {
            sb.append("<w:tr>")
            for (c in 0 until cols) {
                val text = row.getOrNull(c) ?: ""
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"$w\" w:type=\"dxa\"/></w:tcPr>")
                if (text.isEmpty()) sb.append("<w:p/>")
                else sb.append("<w:p>").append(runXml(Run(text, false, false, 11f), false)).append("</w:p>")
                sb.append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl><w:p/>")
        return sb.toString()
    }
}

/** Real .xlsx (one sheet per entry). Numbers are stored as numbers, the rest as text. */
object XlsxWriter {
    private fun colName(index: Int): String {
        var n = index
        val sb = StringBuilder()
        do {
            sb.insert(0, 'A' + (n % 26))
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    private fun asNumber(s: String): Double? {
        val t = s.trim().replace(",", "")
        if (t.isEmpty() || t.length > 15) return null
        if (t.length > 1 && t[0] == '0' && t[1] != '.') return null
        if (!Regex("-?\\d+(\\.\\d+)?").matches(t)) return null
        return t.toDoubleOrNull()
    }

    private fun sheetName(raw: String, used: MutableSet<String>): String {
        var n = raw.replace(Regex("[\\\\/*?:\\[\\]]"), " ").trim().ifEmpty { "Sheet" }
        if (n.length > 31) n = n.substring(0, 31)
        var cand = n
        var k = 2
        while (!used.add(cand.lowercase())) {
            val suffix = " ($k)"
            cand = n.take(31 - suffix.length) + suffix
            k++
        }
        return cand
    }

    fun write(out: File, sheets: List<Pair<String, List<List<String>>>>): Boolean {
        if (sheets.isEmpty()) return false
        return try {
            val used = HashSet<String>()
            val names = sheets.map { sheetName(it.first, used) }
            val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            val types = StringBuilder(head)
            types.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
            types.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
            types.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
            types.append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
            types.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
            sheets.indices.forEach { i ->
                types.append("<Override PartName=\"/xl/worksheets/sheet${i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            }
            types.append("</Types>")
            val rootRels = head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"
            val wb = StringBuilder(head)
            wb.append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>")
            names.forEachIndexed { i, n -> wb.append("<sheet name=\"${xesc(n)}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>") }
            wb.append("</sheets></workbook>")
            val wbRels = StringBuilder(head)
            wbRels.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
            sheets.indices.forEach { i ->
                wbRels.append("<Relationship Id=\"rId${i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i + 1}.xml\"/>")
            }
            wbRels.append("<Relationship Id=\"rId${sheets.size + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>")
            val styles = head + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"1\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/></cellXfs></styleSheet>"

            ZipOutputStream(FileOutputStream(out)).use { z ->
                fun put(name: String, data: String) {
                    z.putNextEntry(ZipEntry(name))
                    z.write(data.toByteArray(Charsets.UTF_8))
                    z.closeEntry()
                }
                put("[Content_Types].xml", types.toString())
                put("_rels/.rels", rootRels)
                put("xl/workbook.xml", wb.toString())
                put("xl/_rels/workbook.xml.rels", wbRels.toString())
                put("xl/styles.xml", styles)
                sheets.forEachIndexed { si, sh ->
                    val sb = StringBuilder(head)
                    sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
                    sh.second.forEachIndexed { ri, row ->
                        if (row.any { it.isNotEmpty() }) {
                            sb.append("<row r=\"${ri + 1}\">")
                            row.forEachIndexed { ci, cell ->
                                if (cell.isNotEmpty()) {
                                    val ref = colName(ci) + (ri + 1)
                                    val num = asNumber(cell)
                                    if (num != null) sb.append("<c r=\"$ref\"><v>${cell.trim().replace(",", "")}</v></c>")
                                    else sb.append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xesc(cell)}</t></is></c>")
                                }
                            }
                            sb.append("</row>")
                        }
                    }
                    sb.append("</sheetData></worksheet>")
                    put("xl/worksheets/sheet${si + 1}.xml", sb.toString())
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Blocks of one page -> rows: tables as rows, other text as one cell per line. */
    fun rowsFromBlocks(blocks: List<Block>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        for (b in blocks) {
            when (b) {
                is Block.Table -> {
                    if (rows.isNotEmpty()) rows.add(emptyList())
                    rows.addAll(b.rows)
                    rows.add(emptyList())
                }
                is Block.Para -> rows.add(listOf(b.text))
                is Block.Img -> {}
            }
        }
        return rows
    }
}
