package com.nova.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

object PdfCore {
    private var inited = false

    fun init(ctx: Context) {
        if (!inited) {
            PDFBoxResourceLoader.init(ctx.applicationContext)
            inited = true
        }
    }

    fun workDir(ctx: Context): File = File(ctx.cacheDir, "pdfwork").also { it.mkdirs() }

    fun clearWork(ctx: Context) {
        File(ctx.cacheDir, "pdfwork").deleteRecursively()
    }

    fun newWorkFile(ctx: Context, prefix: String, ext: String = "pdf"): File =
        File(workDir(ctx), prefix + "_" + System.nanoTime() + "." + ext)

    /** Copy any uri into a private cache file (PdfRenderer and PDFBox need a real file). */
    fun cacheCopy(ctx: Context, uri: Uri): File? {
        return try {
            if (uri.scheme == "file") {
                val p = uri.path
                if (p != null) {
                    val f = File(p)
                    if (f.exists()) return f
                }
            }
            val out = newWorkFile(ctx, "src")
            val input = ctx.contentResolver.openInputStream(uri) ?: return null
            input.use { i -> FileOutputStream(out).use { o -> i.copyTo(o) } }
            out
        } catch (e: Exception) {
            null
        }
    }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    val n = it.getString(0)
                    if (n != null) return n
                }
            }
        } catch (e: Exception) {
            // fall through
        }
        return uri.lastPathSegment ?: "document"
    }

    fun baseName(name: String): String = name.substringBeforeLast('.', name)

    fun load(file: File): PDDocument = PDDocument.load(file, MemoryUsageSetting.setupTempFileOnly())
}

/** Thread-safe wrapper around PdfRenderer (renders pages to bitmaps). */
class PdfSession(val file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val lock = Any()
    private val sizes = HashMap<Int, Pair<Int, Int>>()
    val pageCount: Int = renderer.pageCount

    /** Page size in points (as displayed, rotation applied). */
    fun pageSize(i: Int): Pair<Int, Int> = synchronized(lock) {
        sizes.getOrPut(i) {
            val p = renderer.openPage(i)
            try {
                Pair(p.width, p.height)
            } finally {
                p.close()
            }
        }
    }

    fun render(i: Int, widthPx: Int): Bitmap? = synchronized(lock) {
        try {
            val p = renderer.openPage(i)
            try {
                val h = max(1, (widthPx.toLong() * p.height / max(1, p.width)).toInt())
                val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally {
                p.close()
            }
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    fun close() {
        synchronized(lock) {
            try {
                renderer.close()
                pfd.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}

object PdfText {
    /** Words of one page (0-based) with positions in points, top-left origin, rotation applied. */
    fun extractPage(doc: PDDocument, idx: Int): PageText {
        val page = doc.getPage(idx)
        val box = page.cropBox
        val rot = ((page.rotation % 360) + 360) % 360
        val pw = if (rot == 90 || rot == 270) box.height else box.width
        val ph = if (rot == 90 || rot == 270) box.width else box.height
        val words = ArrayList<WordBox>()
        val stripper = object : PDFTextStripper() {
            override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
                if (text == null || textPositions == null || textPositions.isEmpty()) return
                val t = text.trim()
                if (t.isEmpty()) return
                var x0 = Float.MAX_VALUE
                var x1 = -Float.MAX_VALUE
                var y0 = Float.MAX_VALUE
                var y1 = -Float.MAX_VALUE
                var size = 0f
                for (tp in textPositions) {
                    x0 = min(x0, tp.xDirAdj)
                    x1 = max(x1, tp.xDirAdj + tp.widthDirAdj)
                    y0 = min(y0, tp.yDirAdj - tp.heightDir)
                    y1 = max(y1, tp.yDirAdj)
                    size = max(size, tp.fontSizeInPt)
                }
                val fname = (textPositions[0].font?.name ?: "").lowercase()
                val bold = fname.contains("bold") || fname.contains("black") || fname.contains("heavy")
                val italic = fname.contains("italic") || fname.contains("oblique")
                words.add(WordBox(t, x0, y0, x1, y1, if (size <= 0f) 11f else size, bold, italic))
            }
        }
        stripper.setSortByPosition(true)
        stripper.setStartPage(idx + 1)
        stripper.setEndPage(idx + 1)
        stripper.getText(doc)
        return PageText(pw, ph, words)
    }

    fun plainText(page: PageText): String {
        val sb = StringBuilder()
        val blocks = LayoutAnalyzer.analyze(page)
        for (b in blocks) {
            when (b) {
                is Block.Para -> sb.append(b.text).append("\n")
                is Block.Table -> for (r in b.rows) sb.append(r.joinToString("\t")).append("\n")
                is Block.Img -> {}
            }
        }
        return sb.toString().trim()
    }
}

object PdfBlocks {
    /** Blocks of one page. If the page has no text and [ocr] is given, OCR is used (scanned PDFs). */
    fun page(doc: PDDocument, idx: Int, ocr: ((Int) -> List<Block>)?): List<Block> {
        val pt = PdfText.extractPage(doc, idx)
        val blocks = LayoutAnalyzer.analyze(pt)
        if (blocks.isEmpty()) return if (ocr != null) ocr(idx) else emptyList()
        return blocks + images(doc.getPage(idx))
    }

    private fun images(page: PDPage): List<Block.Img> {
        val out = ArrayList<Block.Img>()
        try {
            val res = page.resources ?: return out
            for (name in res.xObjectNames) {
                if (out.size >= 6) break
                val xo = res.getXObject(name)
                if (xo is PDImageXObject) {
                    val bmp = xo.image ?: continue
                    if (bmp.width < 40 || bmp.height < 40) continue
                    var b = bmp
                    val longest = max(b.width, b.height)
                    if (longest > 1600) {
                        val f = 1600f / longest
                        b = Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
                    }
                    val bos = ByteArrayOutputStream()
                    b.compress(Bitmap.CompressFormat.JPEG, 85, bos)
                    out.add(Block.Img(bos.toByteArray(), b.width, b.height, 380f))
                }
            }
        } catch (e: Exception) {
            // images are optional
        }
        return out
    }
}
