package com.nova.scanner

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.LruCache
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One page of the reader: draws the bitmap, search highlights and the selection rectangle. */
class PdfPageView(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
    var pageW = 1f
    var pageH = 1f
    var highlights: List<RectF> = emptyList()
    var dark = false
    var selectMode = false
    var onSelect: ((RectF) -> Unit)? = null
    private var selRect: RectF? = null
    private var sx = 0f
    private var sy = 0f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val hl = Paint().apply { color = Color.argb(120, 255, 214, 0) }
    private val selPaint = Paint().apply { color = Color.argb(80, 33, 150, 243) }
    private val invert = ColorMatrixColorFilter(
        ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f))
    )

    override fun onDraw(c: Canvas) {
        val b = bmp
        paint.colorFilter = if (dark) invert else null
        if (b != null) c.drawBitmap(b, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)
        else c.drawColor(if (dark) Color.DKGRAY else Color.LTGRAY)
        val s = width / pageW
        for (r in highlights) c.drawRect(r.left * s, r.top * s, r.right * s, r.bottom * s, hl)
        selRect?.let { c.drawRect(it, selPaint) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!selectMode) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x
                sy = e.y
                selRect = RectF(sx, sy, sx, sy)
                parent.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                selRect = RectF(min(sx, e.x), min(sy, e.y), max(sx, e.x), max(sy, e.y))
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val r = selRect
                selRect = null
                invalidate()
                if (r != null && r.width() > 8f && r.height() > 8f) {
                    val k = pageW / width
                    onSelect?.invoke(RectF(r.left * k, r.top * k, r.right * k, r.bottom * k))
                }
                return true
            }
        }
        return true
    }
}

class ZoomFrame(ctx: Context, private val scaleCb: (Float) -> Unit, private val doubleCb: () -> Unit) : FrameLayout(ctx) {
    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            scaleCb(d.scaleFactor)
            return true
        }
    })
    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            doubleCb()
            return true
        }
    })

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        sg.onTouchEvent(ev)
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = ev.pointerCount > 1 || sg.isInProgress

    override fun onTouchEvent(ev: MotionEvent): Boolean = true
}

/** Full-featured PDF reader: zoom, thumbnails, search, bookmarks, dark mode, area text selection. */
class ReaderActivity : AppCompatActivity() {

    private var file: File? = null
    private var session: PdfSession? = null
    private var doc: PDDocument? = null
    private val docLock = Any()
    private val textExec = Executors.newSingleThreadExecutor()
    private val renderExec = Executors.newFixedThreadPool(2)
    private val textCache = HashMap<Int, PageText>()
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private lateinit var rv: RecyclerView
    private lateinit var hsv: HorizontalScrollView
    private lateinit var pageLabel: TextView
    private lateinit var titleView: TextView
    private lateinit var searchBar: LinearLayout
    private lateinit var searchEdit: EditText
    private lateinit var searchInfo: TextView
    private lateinit var lm: LinearLayoutManager
    private var adapter: ReaderAdapter? = null

    private var zoom = 1f
    private var dark = false
    private var selectMode = false
    private var viewW = 0
    private var pageCount = 0
    private var key = ""
    private val highlights = HashMap<Int, MutableList<RectF>>()
    private val matches = ArrayList<Pair<Int, RectF>>()
    private var matchIdx = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewW = resources.displayMetrics.widthPixels
        buildUi()
        val path = intent.getStringExtra("path")
        val data = intent.data
        when {
            path != null -> open(File(path), intent.getStringExtra("title"))
            data != null -> runBusy("Opening PDF\u2026", { _ -> PdfCore.cacheCopy(this, data) }, { f ->
                if (f == null) {
                    toast("Could not open this PDF")
                    finish()
                } else {
                    open(f, PdfCore.displayName(this, data))
                }
            })
            else -> finish()
        }
    }

    override fun onDestroy() {
        session?.close()
        synchronized(docLock) {
            try {
                doc?.close()
            } catch (e: Exception) {
                // ignore
            }
            doc = null
        }
        textExec.shutdown()
        renderExec.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#2B2B2B"))

        val (header, tv) = headerRow("") { finish() }
        titleView = tv
        header.addView(iconBtn("\uD83D\uDD0D") { toggleSearch() })
        header.addView(iconBtn("\u2630") { menu() })
        root.addView(header)

        searchBar = LinearLayout(this)
        searchBar.orientation = LinearLayout.HORIZONTAL
        searchBar.gravity = Gravity.CENTER_VERTICAL
        searchBar.setPadding(dp(10), 0, dp(10), dp(4))
        searchEdit = EditText(this)
        searchEdit.hint = "Search in PDF"
        searchEdit.setHintTextColor(GRAY)
        searchEdit.setTextColor(Color.WHITE)
        searchEdit.maxLines = 1
        searchEdit.inputType = InputType.TYPE_CLASS_TEXT
        searchEdit.setOnEditorActionListener { _, _, _ ->
            runSearch()
            true
        }
        searchBar.addView(searchEdit, LinearLayout.LayoutParams(0, WRAP, 1f))
        searchInfo = TextView(this)
        searchInfo.setTextColor(GRAY)
        searchInfo.textSize = 12f
        searchBar.addView(searchInfo)
        searchBar.addView(iconBtn("\u25B2") { gotoMatch(-1) })
        searchBar.addView(iconBtn("\u25BC") { gotoMatch(1) })
        searchBar.visibility = View.GONE
        root.addView(searchBar)

        val zf = ZoomFrame(this, { f -> applyZoom(zoom * f) }, { applyZoom(if (zoom > 1.2f) 1f else 2f) })
        hsv = HorizontalScrollView(this)
        hsv.isHorizontalScrollBarEnabled = false
        rv = RecyclerView(this)
        lm = LinearLayoutManager(this)
        rv.layoutManager = lm
        hsv.addView(rv, FrameLayout.LayoutParams(viewW, MATCH))
        zf.addView(hsv, FrameLayout.LayoutParams(MATCH, MATCH))
        pageLabel = TextView(this)
        pageLabel.setTextColor(Color.WHITE)
        pageLabel.textSize = 13f
        pageLabel.setPadding(dp(14), dp(7), dp(14), dp(7))
        pageLabel.background = roundBg(Color.argb(190, 0, 0, 0), 16)
        pageLabel.setOnClickListener { gotoDialog() }
        val plp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        plp.bottomMargin = dp(16)
        zf.addView(pageLabel, plp)
        root.addView(zf, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)

        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) {
                updateLabel()
            }
        })
    }

    private fun open(f: File, title: String?) {
        file = f
        key = (f.name + f.length()).hashCode().toString()
        titleView.text = title ?: PdfCore.baseName(f.name)
        try {
            val s = PdfSession(f)
            session = s
            pageCount = s.pageCount
        } catch (e: Exception) {
            toast("This PDF cannot be opened (damaged or password protected)")
            finish()
            return
        }
        adapter = ReaderAdapter()
        rv.adapter = adapter
        val last = prefs().getInt("last_$key", 0)
        if (last in 1 until pageCount) lm.scrollToPositionWithOffset(last, 0)
        updateLabel()
    }

    private fun updateLabel() {
        val p = lm.findFirstVisibleItemPosition()
        if (p >= 0 && pageCount > 0) {
            pageLabel.text = "${p + 1} / $pageCount"
            prefs().edit().putInt("last_$key", p).apply()
        }
    }

    private fun currentPage(): Int = max(0, lm.findFirstVisibleItemPosition())

    private fun applyZoom(z: Float) {
        val nz = z.coerceIn(1f, 4f)
        if (abs(nz - zoom) < 0.01f) return
        val first = lm.findFirstVisibleItemPosition()
        val top = lm.findViewByPosition(first)?.top ?: 0
        val ratio = nz / zoom
        zoom = nz
        rv.layoutParams = FrameLayout.LayoutParams((viewW * zoom).toInt(), MATCH)
        adapter?.notifyDataSetChanged()
        if (first >= 0) lm.scrollToPositionWithOffset(first, (top * ratio).toInt())
        hsv.post { hsv.scrollTo(((hsv.scrollX + viewW / 2f) * ratio - viewW / 2f).toInt().coerceAtLeast(0), 0) }
    }

    // ---------------------------------------------------------------- adapter
    private inner class ReaderAdapter : RecyclerView.Adapter<ReaderAdapter.VH>() {
        inner class VH(val v: PdfPageView) : RecyclerView.ViewHolder(v)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = PdfPageView(parent.context)
            v.layoutParams = RecyclerView.LayoutParams(MATCH, 400)
            return VH(v)
        }

        override fun getItemCount(): Int = pageCount

        override fun onBindViewHolder(h: VH, position: Int) {
            val s = session ?: return
            val sz = s.pageSize(position)
            val w = (viewW * zoom).toInt()
            val hgt = max(1, (w.toLong() * sz.second / max(1, sz.first)).toInt())
            val lp = h.v.layoutParams
            if (lp.height != hgt || lp.width != w) {
                lp.height = hgt
                lp.width = w
                h.v.layoutParams = lp
            }
            h.v.pageW = sz.first.toFloat()
            h.v.pageH = sz.second.toFloat()
            h.v.dark = dark
            h.v.selectMode = selectMode
            h.v.highlights = highlights[position] ?: emptyList()
            h.v.onSelect = { r -> onSelectArea(position, r) }
            val bucket = min(3000, ((w + 149) / 150) * 150)
            val key2 = "$position@$bucket"
            h.v.tag = key2
            val hit = cache.get(key2)
            if (hit != null) {
                h.v.bmp = hit
                h.v.invalidate()
                return
            }
            h.v.bmp = null
            h.v.invalidate()
            renderExec.execute {
                val b = s.render(position, bucket)
                if (b != null) {
                    cache.put(key2, b)
                    h.v.post {
                        if (h.v.tag == key2) {
                            h.v.bmp = b
                            h.v.invalidate()
                        }
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- text (search / select / copy)
    private fun pageText(i: Int): PageText? {
        textCache[i]?.let { return it }
        return synchronized(docLock) {
            try {
                if (doc == null) doc = PdfCore.load(file!!)
                val t = PdfText.extractPage(doc!!, i)
                textCache[i] = t
                t
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun toggleSearch() {
        searchBar.visibility = if (searchBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (searchBar.visibility == View.VISIBLE) searchEdit.requestFocus()
    }

    private fun runSearch() {
        val q = searchEdit.text.toString().trim().lowercase()
        if (q.isEmpty()) return
        searchInfo.text = "searching\u2026"
        matches.clear()
        highlights.clear()
        matchIdx = -1
        textExec.execute {
            for (p in 0 until pageCount) {
                val pt = pageText(p) ?: continue
                val sb = StringBuilder()
                val starts = IntArray(pt.words.size)
                pt.words.forEachIndexed { i, w ->
                    starts[i] = sb.length
                    sb.append(w.text.lowercase()).append(' ')
                }
                val hay = sb.toString()
                var from = 0
                while (true) {
                    val k = hay.indexOf(q, from)
                    if (k < 0) break
                    val end = k + q.length
                    var r: RectF? = null
                    pt.words.forEachIndexed { i, w ->
                        val ws = starts[i]
                        val we = ws + w.text.length
                        if (we > k && ws < end) {
                            val wr = RectF(w.x0, w.y0, w.x1, w.y1)
                            if (r == null) r = wr else r!!.union(wr)
                        }
                    }
                    val rr = r
                    if (rr != null) {
                        matches.add(Pair(p, rr))
                        highlights.getOrPut(p) { ArrayList() }.add(rr)
                    }
                    from = end
                }
            }
            runOnUiThread {
                adapter?.notifyDataSetChanged()
                searchInfo.text = if (matches.isEmpty()) "no results" else "${matches.size} found"
                if (matches.isNotEmpty()) gotoMatch(1)
            }
        }
    }

    private fun gotoMatch(dir: Int) {
        if (matches.isEmpty()) return
        matchIdx = ((matchIdx + dir) % matches.size + matches.size) % matches.size
        val m = matches[matchIdx]
        val s = session ?: return
        val sz = s.pageSize(m.first)
        val scale = (viewW * zoom) / max(1, sz.first)
        lm.scrollToPositionWithOffset(m.first, -(m.second.top * scale).toInt() + dp(120))
        searchInfo.text = "${matchIdx + 1} / ${matches.size}"
    }

    private fun onSelectArea(page: Int, r: RectF) {
        textExec.execute {
            val pt = pageText(page)
            val picked = pt?.words?.filter {
                val cx = (it.x0 + it.x1) / 2f
                val cy = (it.y0 + it.y1) / 2f
                r.contains(cx, cy)
            } ?: emptyList()
            val sb = StringBuilder()
            var lastY = -1000f
            for (w in picked.sortedWith(compareBy({ Math.round(((it.y0 + it.y1) / 2f) / 4f) }, { it.x0 }))) {
                val cy = (w.y0 + w.y1) / 2f
                if (sb.isNotEmpty()) sb.append(if (abs(cy - lastY) > (w.y1 - w.y0) * 0.6f) "\n" else " ")
                sb.append(w.text)
                lastY = cy
            }
            runOnUiThread {
                if (sb.isEmpty()) {
                    toast("No selectable text here (scanned page?). Use OCR for scanned PDFs.")
                } else {
                    showText(sb.toString())
                }
            }
        }
    }

    private fun showText(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextIsSelectable(true)
        tv.textSize = 15f
        tv.setPadding(dp(20), dp(12), dp(20), dp(4))
        AlertDialog.Builder(this)
            .setTitle("Selected text")
            .setView(tv)
            .setPositiveButton("Copy") { _, _ -> Actions.copyText(this, "PDF", text) }
            .setNeutralButton("Search web") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(text))))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------------------------------------------------------------- menu
    private fun bookmarks(): MutableSet<String> =
        HashSet(prefs().getStringSet("bm_$key", emptySet()) ?: emptySet())

    private fun menu() {
        val bm = bookmarks()
        val cur = currentPage()
        val labels = arrayOf(
            "\uD83D\uDDBC  Page thumbnails",
            "\u2192  Go to page\u2026",
            if (bm.contains(cur.toString())) "\u2605  Remove bookmark (page ${cur + 1})" else "\u2606  Bookmark this page (${cur + 1})",
            "\uD83D\uDD16  Bookmarks (${bm.size})",
            if (dark) "\u2600  Light mode" else "\uD83C\uDF19  Dark mode",
            if (selectMode) "\u2716  Stop text selection" else "\uD83D\uDD8A  Select / copy text (drag a box)",
            "\uD83D\uDCCB  Copy this page's text",
            "\uD83D\uDCE4  Share PDF",
            "\uD83E\uDDE9  Organize pages (reorder, extract, merge)",
            "\u270F  Edit / annotate / sign",
            "\uD83D\uDCBE  Save a copy to My Documents"
        )
        AlertDialog.Builder(this)
            .setItems(labels) { _, i ->
                when (i) {
                    0 -> thumbnails()
                    1 -> gotoDialog()
                    2 -> toggleBookmark(cur)
                    3 -> bookmarkList()
                    4 -> {
                        dark = !dark
                        adapter?.notifyDataSetChanged()
                    }
                    5 -> {
                        selectMode = !selectMode
                        adapter?.notifyDataSetChanged()
                        toast(if (selectMode) "Drag a box over the text you want" else "Scrolling mode")
                    }
                    6 -> copyPage(cur)
                    7 -> share()
                    8 -> file?.let { startActivity(Intent(this, OrganizerActivity::class.java).putStringArrayListExtra("paths", arrayListOf(it.absolutePath))) }
                    9 -> file?.let { startActivity(Intent(this, EditorActivity::class.java).putExtra("path", it.absolutePath)) }
                    10 -> saveCopy()
                }
            }
            .show()
    }

    private fun toggleBookmark(p: Int) {
        val bm = bookmarks()
        if (!bm.add(p.toString())) bm.remove(p.toString())
        prefs().edit().putStringSet("bm_$key", bm).apply()
        toast("Bookmarks updated")
    }

    private fun bookmarkList() {
        val pages = bookmarks().mapNotNull { it.toIntOrNull() }.sorted()
        if (pages.isEmpty()) {
            toast("No bookmarks yet")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Bookmarks")
            .setItems(pages.map { "Page ${it + 1}" }.toTypedArray()) { _, i -> lm.scrollToPositionWithOffset(pages[i], 0) }
            .show()
    }

    private fun gotoDialog() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.hint = "1 - $pageCount"
        et.setPadding(dp(20), dp(16), dp(20), dp(8))
        AlertDialog.Builder(this)
            .setTitle("Go to page")
            .setView(et)
            .setPositiveButton("Go") { _, _ ->
                val n = et.text.toString().toIntOrNull()
                if (n != null && n in 1..pageCount) lm.scrollToPositionWithOffset(n - 1, 0) else toast("Enter 1 - $pageCount")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun thumbnails() {
        val s = session ?: return
        val grid = RecyclerView(this)
        grid.layoutManager = GridLayoutManager(this, 3)
        val dlg = AlertDialog.Builder(this).setTitle("Pages").setView(grid).setNegativeButton("Close", null).create()
        grid.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val iv = ImageView(parent.context)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                iv.setBackgroundColor(Color.parseColor("#444444"))
                iv.layoutParams = RecyclerView.LayoutParams(MATCH, dp(150))
                iv.setPadding(dp(3), dp(3), dp(3), dp(3))
                return object : RecyclerView.ViewHolder(iv) {}
            }

            override fun getItemCount(): Int = pageCount

            override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
                val iv = h.itemView as ImageView
                val k = "t$position"
                iv.tag = k
                val hit = cache.get(k)
                if (hit != null) {
                    iv.setImageBitmap(hit)
                } else {
                    iv.setImageDrawable(null)
                    renderExec.execute {
                        val b = s.render(position, 260)
                        if (b != null) {
                            cache.put(k, b)
                            iv.post { if (iv.tag == k) iv.setImageBitmap(b) }
                        }
                    }
                }
                iv.setOnClickListener {
                    dlg.dismiss()
                    lm.scrollToPositionWithOffset(position, 0)
                }
            }
        }
        dlg.show()
    }

    private fun copyPage(p: Int) {
        textExec.execute {
            val pt = pageText(p)
            val t = if (pt == null) "" else PdfText.plainText(pt)
            runOnUiThread {
                if (t.isBlank()) toast("No selectable text on this page (scanned?). Use OCR.") else Actions.copyText(this, "PDF", t)
            }
        }
    }

    private fun share() {
        val f = file ?: return
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, packageName + ".fileprovider", f)
            val i = Intent(Intent.ACTION_SEND)
            i.type = "application/pdf"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share PDF"))
        } catch (e: Exception) {
            toast("Could not share this file")
        }
    }

    private fun saveCopy() {
        val f = file ?: return
        runBusy("Saving\u2026", { _ -> ScanStore.addPdf(this, f, titleView.text.toString()) }, { s ->
            toast(if (s != null) "Saved to My Documents" else "Could not save")
        })
    }
}
