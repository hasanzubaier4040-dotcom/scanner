package com.nova.scanner

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max

/** src >= 0: page of sources[src]; -1: blank page; -2: image page. */
class PageRef(val src: Int, val page: Int, var rot: Int, val imageUri: Uri? = null) {
    var selected = false
}

/** Merge PDFs, reorder / rotate / delete / duplicate / insert pages, extract selected pages. */
class OrganizerActivity : AppCompatActivity() {

    private val sources = ArrayList<File>()
    private val sessions = ArrayList<PdfSession?>()
    private val refs = ArrayList<PageRef>()
    private lateinit var adapter: OrgAdapter
    private lateinit var info: TextView
    private val pool = Executors.newFixedThreadPool(2)

    private val addPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                runBusy("Reading PDFs\u2026", { _ ->
                    uris.mapNotNull { PdfCore.cacheCopy(this, it) }
                }, { files -> if (files != null) addFiles(files) })
            }
        }

    private val addImagePicker =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            val at = refs.size
            uris.forEach { refs.add(PageRef(-2, 0, 0, it)) }
            adapter.notifyItemRangeInserted(at, uris.size)
            updateInfo()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val paths = intent.getStringArrayListExtra("paths")
        if (paths != null && paths.isNotEmpty()) addFiles(paths.map { File(it) })
        else addPdfPicker.launch(arrayOf("application/pdf"))
    }

    override fun onDestroy() {
        sessions.forEach { it?.close() }
        pool.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val (header, _) = headerRow("Organize / Merge PDF") { finish() }
        root.addView(header)
        info = TextView(this)
        info.setTextColor(GRAY)
        info.textSize = 12f
        info.setPadding(dp(18), 0, dp(18), dp(4))
        root.addView(info)

        root.addView(chipScroll(listOf(
            chip("\uFF0B PDF") { addPdfPicker.launch(arrayOf("application/pdf")) },
            chip("\uFF0B Images") { addImagePicker.launch("image/*") },
            chip("\uFF0B Blank page") { insertBlank() },
            chip("\u21BB Right") { rotateSel(90) },
            chip("\u21BA Left") { rotateSel(270) },
            chip("\u29C9 Duplicate") { duplicateSel() },
            chip("\uD83D\uDDD1 Delete") { deleteSel() },
            chip("\u2611 All / none") { toggleAll() }
        )))

        val rv = RecyclerView(this)
        rv.layoutManager = GridLayoutManager(this, 3)
        adapter = OrgAdapter()
        rv.adapter = adapter
        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(r: RecyclerView, vh: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder): Boolean {
                val a = vh.bindingAdapterPosition
                val b = t.bindingAdapterPosition
                if (a < 0 || b < 0) return false
                refs.add(b, refs.removeAt(a))
                adapter.notifyItemMoved(a, b)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}
        })
        touch.attachToRecyclerView(rv)
        root.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(8), dp(4), dp(8), dp(10))
        val l1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l1.setMargins(dp(4), 0, dp(4), 0)
        val l2 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l2.setMargins(dp(4), 0, dp(4), 0)
        bar.addView(bigButton("\uD83D\uDCBE Save all pages", GREEN) { save(false) }, l1)
        bar.addView(bigButton("\u2702 Extract selected", BLUE) { save(true) }, l2)
        root.addView(bar)
        setContentView(root)
        updateInfo()
    }

    private fun updateInfo() {
        val sel = refs.count { it.selected }
        info.text = "${refs.size} page(s)  \u2022  $sel selected  \u2022  tap to select, long-press and drag to reorder"
    }

    private fun addFiles(files: List<File>) {
        for (f in files) {
            try {
                val s = PdfSession(f)
                sources.add(f)
                sessions.add(s)
                val idx = sources.size - 1
                val at = refs.size
                for (p in 0 until s.pageCount) refs.add(PageRef(idx, p, 0))
                adapter.notifyItemRangeInserted(at, s.pageCount)
            } catch (e: Exception) {
                toast("Skipped an unreadable or protected PDF")
            }
        }
        updateInfo()
    }

    private fun selectedIdx(): List<Int> = refs.indices.filter { refs[it].selected }

    private fun insertBlank() {
        val sel = selectedIdx()
        val at = if (sel.isEmpty()) refs.size else sel.last() + 1
        refs.add(at, PageRef(-1, 0, 0))
        adapter.notifyItemInserted(at)
        updateInfo()
    }

    private fun rotateSel(deg: Int) {
        val sel = selectedIdx()
        if (sel.isEmpty()) {
            toast("Select pages first")
            return
        }
        for (i in sel) {
            refs[i].rot = (refs[i].rot + deg) % 360
            adapter.notifyItemChanged(i)
        }
    }

    private fun duplicateSel() {
        val sel = selectedIdx()
        if (sel.isEmpty()) {
            toast("Select pages first")
            return
        }
        for (i in sel.reversed()) {
            val r = refs[i]
            refs.add(i + 1, PageRef(r.src, r.page, r.rot, r.imageUri))
        }
        adapter.notifyDataSetChanged()
        updateInfo()
    }

    private fun deleteSel() {
        val sel = selectedIdx()
        if (sel.isEmpty()) {
            toast("Select pages first")
            return
        }
        for (i in sel.reversed()) refs.removeAt(i)
        adapter.notifyDataSetChanged()
        updateInfo()
    }

    private fun toggleAll() {
        val all = refs.all { it.selected }
        refs.forEach { it.selected = !all }
        adapter.notifyDataSetChanged()
        updateInfo()
    }

    // ---------------------------------------------------------------- saving
    private fun save(onlySelected: Boolean) {
        val list = if (onlySelected) refs.filter { it.selected } else refs.toList()
        if (list.isEmpty()) {
            toast(if (onlySelected) "Select pages first" else "No pages")
            return
        }
        val name = if (onlySelected) "Extract" else if (sources.size > 1) "Merged" else "Organized"
        runBusy("Building PDF\u2026", { p ->
            val out = PdfCore.newWorkFile(this, "org")
            if (buildPdf(list, out, p)) ScanStore.addPdf(this, out, name + " " + defaultName(System.currentTimeMillis()).removePrefix("Scan ")) else null
        }, { s ->
            if (s == null) {
                toast("Could not build the PDF")
            } else {
                startActivity(Intent(this, ReaderActivity::class.java).putExtra("path", s.pdf?.absolutePath).putExtra("title", s.name))
                finish()
            }
        })
    }

    private fun buildPdf(list: List<PageRef>, out: File, progress: (String) -> Unit): Boolean {
        val docs = HashMap<Int, PDDocument>()
        val dest = PDDocument(MemoryUsageSetting.setupTempFileOnly())
        return try {
            list.forEachIndexed { i, r ->
                progress("Page ${i + 1} / ${list.size}\u2026")
                when {
                    r.src >= 0 -> {
                        val d = docs.getOrPut(r.src) { PdfCore.load(sources[r.src]) }
                        val p = dest.importPage(d.getPage(r.page))
                        p.rotation = ((p.rotation + r.rot) % 360 + 360) % 360
                    }
                    r.src == -1 -> {
                        val p = PDPage(PDRectangle.A4)
                        dest.addPage(p)
                        p.rotation = r.rot
                    }
                    else -> {
                        val bmp = r.imageUri?.let { ImageUtil.decode(this, it, 2400, Int.MAX_VALUE, r.rot) }
                        if (bmp != null) {
                            val k = 842f / max(bmp.width, bmp.height)
                            val w = bmp.width * k
                            val h = bmp.height * k
                            val p = PDPage(PDRectangle(w, h))
                            dest.addPage(p)
                            val img = JPEGFactory.createFromImage(dest, bmp, 0.9f)
                            PDPageContentStream(dest, p).use { cs -> cs.drawImage(img, 0f, 0f, w, h) }
                            bmp.recycle()
                        }
                    }
                }
            }
            dest.save(out)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                dest.close()
                docs.values.forEach { it.close() }
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // ---------------------------------------------------------------- adapter
    private inner class OrgAdapter : RecyclerView.Adapter<OrgAdapter.VH>() {
        inner class VH(val frame: FrameLayout, val iv: ImageView, val num: TextView, val check: TextView) :
            RecyclerView.ViewHolder(frame)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val c = parent.context
            val frame = FrameLayout(c)
            frame.setPadding(dp(4), dp(4), dp(4), dp(4))
            frame.layoutParams = RecyclerView.LayoutParams(MATCH, dp(190))
            val iv = ImageView(c)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setBackgroundColor(Color.parseColor("#333333"))
            frame.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
            val num = TextView(c)
            num.setTextColor(Color.WHITE)
            num.textSize = 12f
            num.setPadding(dp(8), dp(3), dp(8), dp(3))
            num.background = roundBg(Color.argb(170, 0, 0, 0), 10)
            frame.addView(num, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START))
            val check = TextView(c)
            check.text = "\u2714"
            check.setTextColor(Color.WHITE)
            check.textSize = 16f
            check.gravity = Gravity.CENTER
            check.background = roundBg(GREEN, 14)
            frame.addView(check, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END))
            return VH(frame, iv, num, check)
        }

        override fun getItemCount(): Int = refs.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val r = refs[position]
            h.num.text = (position + 1).toString() + (if (r.src == -1) "  blank" else "")
            h.check.visibility = if (r.selected) android.view.View.VISIBLE else android.view.View.GONE
            h.frame.setBackgroundColor(if (r.selected) Color.parseColor("#14532D") else BG)
            h.iv.rotation = r.rot.toFloat()
            h.frame.setOnClickListener {
                val p = h.bindingAdapterPosition
                if (p >= 0) {
                    refs[p].selected = !refs[p].selected
                    notifyItemChanged(p)
                    updateInfo()
                }
            }
            val key = "${r.src}:${r.page}:${r.imageUri}"
            h.iv.tag = key
            if (r.src == -1) {
                h.iv.setImageBitmap(Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888).also { it.eraseColor(Color.WHITE) })
                return
            }
            h.iv.setImageDrawable(null)
            pool.execute {
                val bmp: Bitmap? = if (r.src >= 0) sessions[r.src]?.render(r.page, 260)
                else r.imageUri?.let { ImageUtil.decode(this@OrganizerActivity, it, 260) }
                if (bmp != null) h.iv.post { if (h.iv.tag == key) h.iv.setImageBitmap(bmp) }
            }
        }
    }
}
