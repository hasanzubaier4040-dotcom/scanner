package com.nova.scanner

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult

/** Home screen. */
class MainActivity : AppCompatActivity() {

    private lateinit var libSub: TextView

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
                if (res != null) {
                    val uris = res.pages?.map { it.imageUri } ?: emptyList()
                    val pdfUri = res.pdf?.uri
                    runBusy("Saving scan\u2026", { _ ->
                        ScanStore.createFromScanner(applicationContext, uris, pdfUri)
                    }, { s ->
                        if (s != null) {
                            startActivity(Intent(this, DetailActivity::class.java).putExtra("id", s.id))
                        } else {
                            toast("Could not save the scan")
                        }
                    })
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Exporter.clearCache(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        val n = ScanStore.list(this).size
        libSub.text = if (n == 0) "Nothing saved yet" else "$n document" + (if (n == 1) "" else "s")
    }

    private fun tile(icon: String, title: String, sub: String, color: Int, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.setPadding(dp(16), dp(18), dp(16), dp(18))
        t.background = roundBg(color, 18)
        t.setOnClickListener { onClick() }
        val i = TextView(this)
        i.text = icon
        i.textSize = 30f
        t.addView(i)
        val tt = TextView(this)
        tt.text = title
        tt.textSize = 16f
        tt.typeface = Typeface.DEFAULT_BOLD
        tt.setTextColor(Color.WHITE)
        tt.setPadding(0, dp(8), 0, 0)
        t.addView(tt)
        val ss = TextView(this)
        ss.text = sub
        ss.textSize = 12f
        ss.setTextColor(Color.parseColor("#E5E7EB"))
        t.addView(ss)
        if (title == "My Documents") libSub = ss
        return t
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val title = TextView(this)
        title.text = "Nova Scanner"
        title.textSize = 26f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(20), dp(20), dp(20), dp(2))
        root.addView(title)
        val sub = TextView(this)
        sub.text = "Scan  \u2022  OCR  \u2022  QR  \u2022  PDF  \u2022  100% free, no ads"
        sub.textSize = 12f
        sub.setTextColor(GRAY)
        sub.setPadding(dp(20), 0, dp(20), dp(12))
        root.addView(sub)

        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(dp(12), dp(4), dp(12), dp(16))

        val tiles = listOf(
            tile("\uD83D\uDCF7", "Scan Document", "Camera, auto-crop, filters", GREEN) { startScan() },
            tile("\uD83D\uDDBC", "Images \u2192 PDF", "Page size, margins, quality", BLUE) {
                startActivity(Intent(this, ImagesToPdfActivity::class.java))
            },
            tile("\uD83D\uDD24", "OCR  Image \u2192 Text", "English + Bangla, to Word/TXT/PDF", PURPLE) {
                startActivity(Intent(this, OcrActivity::class.java))
            },
            tile("\u25A6", "QR / Barcode", "Camera, image, PDF", ORANGE) {
                startActivity(Intent(this, QrActivity::class.java))
            },
            tile("\uD83D\uDCC1", "My Documents", "", Color.parseColor("#374151")) {
                startActivity(Intent(this, LibraryActivity::class.java))
            }
        )
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                lp.setMargins(dp(6), dp(6), dp(6), dp(6))
                if (i + k < tiles.size) {
                    row.addView(tiles[i + k], lp)
                } else {
                    val spacer = View(this)
                    row.addView(spacer, lp)
                }
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH, dp(150)))
            i += 2
        }

        val sv = ScrollView(this)
        sv.addView(grid)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun startScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                scanLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }
            .addOnFailureListener { e ->
                toast("Scanner not available: " + (e.message ?: "unknown error"))
            }
    }
}
