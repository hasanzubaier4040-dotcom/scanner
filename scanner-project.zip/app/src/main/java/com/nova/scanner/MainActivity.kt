package com.nova.scanner

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult

/** Home screen with every tool. */
class MainActivity : AppCompatActivity() {

    private var libSub: TextView? = null
    private lateinit var qualityChip: TextView
    private var pdfTarget = "reader"

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
                if (res != null) {
                    val uris = res.pages?.map { it.imageUri } ?: emptyList()
                    val pdfUri = res.pdf?.uri
                    runBusy("Saving scan\u2026", { _ ->
                        val s = ScanStore.createFromScanner(applicationContext, uris, pdfUri)
                        if (s != null) ScanStore.applyQuality(applicationContext, s) else null
                    }, { s ->
                        if (s != null) {
                            startActivity(Intent(this, DetailActivity::class.java).putExtra("id", s.id))
                        } else {
                            toast("Could not save the scan")
                        }
                    })
                }
            }
        }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val target = pdfTarget
            runBusy("Opening PDF\u2026", { _ -> PdfCore.cacheCopy(this, uri) }, { f ->
                if (f == null) {
                    toast("Could not open this PDF")
                } else {
                    val cls = if (target == "editor") EditorActivity::class.java else ReaderActivity::class.java
                    startActivity(Intent(this, cls).putExtra("path", f.absolutePath).putExtra("title", PdfCore.baseName(PdfCore.displayName(this, uri))))
                }
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Exporter.clearCache(this)
        PdfCore.clearWork(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        val n = ScanStore.list(this).size
        libSub?.text = if (n == 0) "Nothing saved yet" else "$n document" + (if (n == 1) "" else "s")
        qualityChip.text = "\u2699 Quality:  " + Quality.fullSummary(this)
    }

    private fun tile(icon: String, title: String, sub: String, color: Int, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.setPadding(dp(14), dp(14), dp(14), dp(12))
        t.background = roundBg(color, 16)
        t.setOnClickListener { onClick() }
        val i = TextView(this)
        i.text = icon
        i.textSize = 26f
        t.addView(i)
        val tt = TextView(this)
        tt.text = title
        tt.textSize = 15f
        tt.typeface = Typeface.DEFAULT_BOLD
        tt.setTextColor(Color.WHITE)
        tt.setPadding(0, dp(6), 0, 0)
        t.addView(tt)
        val ss = TextView(this)
        ss.text = sub
        ss.textSize = 11f
        ss.setTextColor(Color.parseColor("#E5E7EB"))
        t.addView(ss)
        if (title == "Document Library") libSub = ss
        return t
    }

    private fun go(cls: Class<*>, vararg extras: Pair<String, String>) {
        val i = Intent(this, cls)
        for ((k, v) in extras) i.putExtra(k, v)
        startActivity(i)
    }

    private fun convert(mode: String) = go(ConvertActivity::class.java, Pair("mode", mode))

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val title = TextView(this)
        title.text = "Nova Scanner"
        title.textSize = 26f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(20), dp(18), dp(20), dp(2))
        root.addView(title)
        val sub = TextView(this)
        sub.text = "Scan  \u2022  OCR  \u2022  PDF tools  \u2022  100% free, no ads"
        sub.textSize = 12f
        sub.setTextColor(GRAY)
        sub.setPadding(dp(20), 0, dp(20), dp(6))
        root.addView(sub)
        qualityChip = chip("") { Quality.showDialog(this, true) { onResume() } }
        root.addView(chipScroll(listOf(qualityChip)))

        val G = GREEN
        val B = BLUE
        val P = PURPLE
        val O = ORANGE
        val S = Color.parseColor("#374151")
        val T = Color.parseColor("#0F766E")
        val tiles = listOf(
            tile("\uD83D\uDCF7", "Scan Document", "Camera, auto-crop, quality", G) { go(ProCameraActivity::class.java) },
            tile("\u26A1", "Quick Scan", "Google scanner (fast)", G) { startQuickScan() },
            tile("\uD83D\uDDBC", "Import Image", "Crop, filter, save", B) {
                startActivity(Intent(this, ProCameraActivity::class.java).putExtra("import", true))
            },
            tile("\uD83D\uDCD6", "PDF Reader", "Search, zoom, dark mode", S) { pdfTarget = "reader"; pdfPicker.launch(arrayOf("application/pdf")) },
            tile("\u270F", "PDF Editor", "Text, sign, draw, shapes", S) { pdfTarget = "editor"; pdfPicker.launch(arrayOf("application/pdf")) },
            tile("\uD83E\uDDE9", "Merge PDF", "Combine, reorder, delete", O) { go(OrganizerActivity::class.java) },
            tile("\u2702", "Split PDF", "Ranges, every page", O) { go(SplitActivity::class.java) },
            tile("\uD83D\uDCDD", "PDF \u2192 Word", "Text, tables, images", B) { convert("pdf2docx") },
            tile("\uD83D\uDCCA", "PDF \u2192 Excel", "Tables to rows/columns", B) { convert("pdf2xlsx") },
            tile("\uD83D\uDCC4", "Word \u2192 PDF", ".docx to PDF", T) { convert("docx2pdf") },
            tile("\uD83D\uDCC8", "Excel \u2192 PDF", ".xlsx to PDF", T) { convert("xlsx2pdf") },
            tile("\uD83D\uDDBC", "Image \u2192 PDF", "Size, margins, quality", T) { go(ImagesToPdfActivity::class.java) },
            tile("\uD83D\uDD24", "OCR", "Bangla + English, Word/TXT", P) { go(OcrActivity::class.java) },
            tile("\u2728", "AI Enhance", "Sharpen, shadows, B&W", P) { go(EnhanceActivity::class.java) },
            tile("\u25A6", "QR / Barcode", "Camera, image, PDF", O) { go(QrActivity::class.java) },
            tile("\uD83D\uDD01", "More converters", "PDF\u2192Images, PDF\u2192TXT, TXT\u2192PDF", T) { convert("hub") },
            tile("\uD83D\uDCC1", "Document Library", "", Color.parseColor("#1F2937")) { go(LibraryActivity::class.java) }
        )
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(dp(10), dp(4), dp(10), dp(16))
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0..1) {
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                lp.setMargins(dp(5), dp(5), dp(5), dp(5))
                if (i + k < tiles.size) row.addView(tiles[i + k], lp) else row.addView(View(this), lp)
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH, dp(124)))
            i += 2
        }
        val sv = ScrollView(this)
        sv.addView(grid)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun startQuickScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG, GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender -> scanLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
            .addOnFailureListener { e -> toast("Scanner not available: " + (e.message ?: "unknown error")) }
    }
}
