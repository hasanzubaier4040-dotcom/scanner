package com.nova.scanner

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.common.InputImage

/** QR + barcode reader: camera, gallery images, PDF pages, saved documents. */
class QrActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val found = LinkedHashSet<String>()

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) scanJobs(Sources.expand(this, uris))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val id = intent.getLongExtra("id", -1L)
        if (id > 0) {
            val s = ScanStore.find(this, id)
            if (s != null) scanJobs(Sources.fromScan(s))
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val (header, _) = headerRow("QR  \u2022  Barcode scanner") { finish() }
        root.addView(header)

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.setPadding(dp(8), dp(4), dp(8), dp(4))
        val lp1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp1.setMargins(dp(4), 0, dp(4), 0)
        val lp2 = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp2.setMargins(dp(4), 0, dp(4), 0)
        btns.addView(bigButton("\uD83D\uDCF7 Camera", ORANGE) { scanCamera() }, lp1)
        btns.addView(bigButton("\uD83D\uDDBC Image / PDF", BLUE) {
            picker.launch(arrayOf("image/*", "application/pdf"))
        }, lp2)
        root.addView(btns)

        status = TextView(this)
        status.setTextColor(GRAY)
        status.textSize = 13f
        status.text = "Scan with the camera, or pick an image / PDF that contains a QR code or barcode."
        status.setPadding(dp(16), dp(8), dp(16), dp(8))
        root.addView(status)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(12), 0, dp(12), dp(12))
        val sv = ScrollView(this)
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun scanCamera() {
        GmsBarcodeScanning.getClient(this)
            .startScan()
            .addOnSuccessListener { b ->
                addCode(b, "Camera")
                status.text = "Scan complete."
            }
            .addOnFailureListener { e ->
                val m = e.message ?: ""
                if (!m.contains("cancel", true)) toast("Scanner error: $m")
            }
    }

    private fun scanJobs(jobs: List<PageJob>) {
        if (jobs.isEmpty()) {
            toast("Nothing to scan")
            return
        }
        status.text = "Scanning\u2026"
        Thread {
            val scanner = BarcodeScanning.getClient(
                BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build()
            )
            val loader = Sources.Loader(applicationContext)
            var count = 0
            try {
                for ((i, job) in jobs.withIndex()) {
                    runOnUiThread { status.text = "Scanning " + job.label + " (" + (i + 1) + "/" + jobs.size + ")\u2026" }
                    val bmp = loader.bitmap(job, 2400) ?: continue
                    val codes: List<Barcode> = try {
                        Tasks.await(scanner.process(InputImage.fromBitmap(bmp, 0)))
                    } catch (e: Exception) {
                        emptyList()
                    }
                    bmp.recycle()
                    for (c in codes) {
                        count++
                        runOnUiThread { addCode(c, job.label) }
                    }
                }
            } finally {
                loader.close()
                scanner.close()
            }
            runOnUiThread {
                status.text = if (count == 0) "No QR code or barcode found." else "Found $count code(s)."
            }
        }.start()
    }

    private fun typeName(b: Barcode): String = when (b.valueType) {
        Barcode.TYPE_URL -> "Website"
        Barcode.TYPE_WIFI -> "Wi-Fi"
        Barcode.TYPE_EMAIL -> "Email"
        Barcode.TYPE_PHONE -> "Phone"
        Barcode.TYPE_SMS -> "SMS"
        Barcode.TYPE_CONTACT_INFO -> "Contact"
        Barcode.TYPE_GEO -> "Location"
        Barcode.TYPE_CALENDAR_EVENT -> "Event"
        Barcode.TYPE_PRODUCT -> "Product"
        Barcode.TYPE_ISBN -> "Book (ISBN)"
        else -> "Text"
    }

    private fun formatName(b: Barcode): String = when (b.format) {
        Barcode.FORMAT_QR_CODE -> "QR code"
        Barcode.FORMAT_EAN_13 -> "EAN-13"
        Barcode.FORMAT_EAN_8 -> "EAN-8"
        Barcode.FORMAT_UPC_A -> "UPC-A"
        Barcode.FORMAT_UPC_E -> "UPC-E"
        Barcode.FORMAT_CODE_128 -> "Code 128"
        Barcode.FORMAT_CODE_39 -> "Code 39"
        Barcode.FORMAT_CODE_93 -> "Code 93"
        Barcode.FORMAT_CODABAR -> "Codabar"
        Barcode.FORMAT_ITF -> "ITF"
        Barcode.FORMAT_PDF417 -> "PDF417"
        Barcode.FORMAT_AZTEC -> "Aztec"
        Barcode.FORMAT_DATA_MATRIX -> "Data Matrix"
        else -> "Barcode"
    }

    private fun fixUrl(u: String): String = if (u.contains("://")) u else "https://$u"

    private fun openIntent(b: Barcode, raw: String): Intent? {
        val url = b.url?.url ?: raw
        return when {
            b.valueType == Barcode.TYPE_URL || url.startsWith("http://", true) || url.startsWith("https://", true) ->
                Intent(Intent.ACTION_VIEW, Uri.parse(fixUrl(url)))
            raw.startsWith("www.", true) -> Intent(Intent.ACTION_VIEW, Uri.parse("https://$raw"))
            b.valueType == Barcode.TYPE_PHONE ->
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + (b.phone?.number ?: raw)))
            b.valueType == Barcode.TYPE_EMAIL ->
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + (b.email?.address ?: raw)))
            b.valueType == Barcode.TYPE_GEO && b.geoPoint != null ->
                Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + b.geoPoint!!.lat + "," + b.geoPoint!!.lng))
            else -> null
        }
    }

    private fun launch(i: Intent) {
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("No app found to open this")
        }
    }

    private fun addCode(b: Barcode, source: String) {
        val raw = b.rawValue ?: b.displayValue ?: return
        if (!found.add(raw)) return

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = roundBg(CARD, 12)
        card.setPadding(dp(14), dp(12), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)

        val head = TextView(this)
        head.text = typeName(b) + "  \u2022  " + formatName(b) + "  \u2022  " + source
        head.setTextColor(GRAY)
        head.textSize = 12f
        card.addView(head)

        val body = TextView(this)
        body.text = raw
        body.setTextColor(Color.WHITE)
        body.textSize = 16f
        body.typeface = Typeface.DEFAULT_BOLD
        body.setTextIsSelectable(true)
        body.setPadding(0, dp(6), 0, dp(8))
        card.addView(body)

        val chips = ArrayList<View>()
        val open = openIntent(b, raw)
        if (open != null) chips.add(chip("\uD83C\uDF10 Open") { launch(open) })
        chips.add(chip("\uD83D\uDD0E Search web") {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(raw))))
        })
        chips.add(chip("\uD83D\uDCCB Copy") { Actions.copyText(this, "QR", raw) })
        chips.add(chip("\uD83D\uDCE4 Share") {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, raw)
            startActivity(Intent.createChooser(i, "Share"))
        })
        card.addView(chipScroll(chips))
        list.addView(card, 0, lp)
    }
}
