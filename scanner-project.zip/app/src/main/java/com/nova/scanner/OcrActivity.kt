package com.nova.scanner

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

/** Image / PDF / scan -> editable text -> TXT, Word (.docx), PDF. */
class OcrActivity : AppCompatActivity() {

    private lateinit var edit: EditText
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var progressRow: LinearLayout
    private lateinit var engineChip: TextView
    private var working = false

    @Volatile
    private var cancel = false
    private var engine = 0 // 0 = ML Kit (English/Latin), 1 = Tesseract (Bangla + English)

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) start(Sources.expand(this, uris))
        }

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
                val uris = res?.pages?.map { it.imageUri } ?: emptyList()
                if (uris.isNotEmpty()) start(Sources.expand(this, uris))
            }
        }

    private val saveTxt =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            if (uri != null) writeUri(uri, edit.text.toString().toByteArray(Charsets.UTF_8))
        }

    private val saveDocx = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri ->
        if (uri != null) {
            val f = File(cacheDir, "ocr_export.docx")
            if (DocxWriter.write(f, OcrText.split(edit.text.toString()))) writeUri(uri, f.readBytes())
            else toast("Could not create the Word file")
        }
    }

    private val savePdf =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
            if (uri != null) {
                val f = File(cacheDir, "ocr_export.pdf")
                if (TextPdf.write(f, OcrText.split(edit.text.toString()))) writeUri(uri, f.readBytes())
                else toast("Could not create the PDF")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = prefs().getInt("ocr_engine", 0).coerceIn(0, 1)
        buildUi()
        val id = intent.getLongExtra("id", -1L)
        if (id > 0) {
            val s = ScanStore.find(this, id)
            if (s != null) start(Sources.fromScan(s))
        } else {
            chooseSource()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val (header, _) = headerRow("OCR  \u2022  Image to Text") { finish() }
        root.addView(header)

        engineChip = chip("") { chooseEngine() }
        root.addView(chipScroll(listOf(chip("\uD83D\uDCC2 Choose source") { chooseSource() }, engineChip)))
        updateEngineChip()

        progressRow = LinearLayout(this)
        progressRow.orientation = LinearLayout.VERTICAL
        progressRow.setPadding(dp(16), dp(4), dp(16), dp(4))
        status = TextView(this)
        status.setTextColor(GRAY)
        status.textSize = 12f
        progressRow.addView(status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressRow.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        progressRow.addView(chip("\u25A0 Stop") { cancel = true })
        progressRow.visibility = View.GONE
        root.addView(progressRow)

        edit = EditText(this)
        edit.hint = "Recognized text appears here.\nYou can edit it before exporting."
        edit.setHintTextColor(GRAY)
        edit.setTextColor(Color.WHITE)
        edit.textSize = 15f
        edit.gravity = Gravity.TOP or Gravity.START
        edit.setPadding(dp(14), dp(12), dp(14), dp(12))
        edit.background = roundBg(CARD, 12)
        val lp = LinearLayout.LayoutParams(MATCH, 0, 1f)
        lp.setMargins(dp(12), dp(6), dp(12), dp(6))
        root.addView(edit, lp)

        root.addView(chipScroll(listOf(
            chip("\uD83D\uDCCB Copy") { copy() },
            chip("\uD83D\uDCE4 Share") { shareText() },
            chip("TXT") { if (hasText()) saveTxt.launch("OCR_" + System.currentTimeMillis() + ".txt") },
            chip("Word (.docx)") { if (hasText()) saveDocx.launch("OCR_" + System.currentTimeMillis() + ".docx") },
            chip("PDF") { if (hasText()) savePdf.launch("OCR_" + System.currentTimeMillis() + ".pdf") }
        )))
        setContentView(root)
    }

    private fun updateEngineChip() {
        engineChip.text = "\uD83E\uDDE0 Engine: " + if (engine == 0) "English / numbers" else "Bangla + English"
    }

    private fun chooseEngine() {
        chooseDialog(
            "Text recognition engine",
            arrayOf(
                "English / Latin, numbers  (fast, built-in, neat handwriting sometimes)",
                "Bangla + English  (Tesseract, one-time language download ~5 MB)"
            ),
            engine
        ) {
            engine = it
            prefs().edit().putInt("ocr_engine", it).apply()
            updateEngineChip()
        }
    }

    private fun chooseSource() {
        AlertDialog.Builder(this)
            .setTitle("Read text from")
            .setItems(arrayOf("\uD83D\uDCF7 Scan with camera", "\uD83D\uDDBC Images or \uD83D\uDCC4 PDF files")) { _, i ->
                if (i == 0) startScanner() else picker.launch(arrayOf("image/*", "application/pdf"))
            }
            .show()
    }

    private fun startScanner() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { scanLauncher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { toast("Scanner not available: " + (it.message ?: "")) }
    }

    // ---------------------------------------------------------------- recognition
    private fun setStatus(m: String) {
        runOnUiThread { status.text = m }
    }

    private fun ensureTess(): Boolean {
        val dir = File(filesDir, "tess/tessdata")
        for (lang in arrayOf("ben", "eng")) {
            val f = File(dir, "$lang.traineddata")
            if (f.exists() && f.length() > 100_000) continue
            setStatus("Downloading $lang language data (one time)\u2026")
            val ok = Net.download("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata", f) { pct ->
                setStatus("Downloading $lang language data\u2026 $pct%")
            }
            if (!ok) return false
        }
        return true
    }

    private fun mlKitText(r: TextRecognizer, bmp: Bitmap): String {
        val t = Tasks.await(r.process(InputImage.fromBitmap(bmp, 0)))
        return t.textBlocks.joinToString("\n\n") { b -> b.lines.joinToString("\n") { it.text } }
    }

    private fun tessText(t: TessBaseAPI, bmp: Bitmap): String {
        t.setImage(bmp)
        return t.getUTF8Text() ?: ""
    }

    private fun showResults(list: List<String>, total: Int) {
        edit.setText(
            if (total == 1) (list.firstOrNull() ?: "")
            else list.mapIndexed { i, t -> OcrText.header(i + 1) + t }.joinToString("\n\n")
        )
    }

    private fun start(jobs: List<PageJob>) {
        if (jobs.isEmpty()) {
            toast("Nothing to read")
            return
        }
        if (working) {
            toast("Please wait, still working")
            return
        }
        working = true
        cancel = false
        edit.isEnabled = false
        edit.setText("")
        bar.max = jobs.size
        bar.progress = 0
        progressRow.visibility = View.VISIBLE
        val eng = engine
        Thread {
            val results = ArrayList<String>()
            var tess: TessBaseAPI? = null
            var recognizer: TextRecognizer? = null
            val loader = Sources.Loader(applicationContext)
            var err: String? = null
            try {
                if (eng == 1) {
                    if (!ensureTess()) {
                        err = "Could not download Bangla language data. Check your internet and try again."
                        throw IllegalStateException("download")
                    }
                    val t = TessBaseAPI()
                    tess = t
                    if (!t.init(File(filesDir, "tess").absolutePath, "ben+eng")) {
                        err = "Could not start the Bangla engine."
                        throw IllegalStateException("init")
                    }
                } else {
                    recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                }
                for ((i, job) in jobs.withIndex()) {
                    if (cancel) break
                    setStatus("Reading " + job.label + " (" + (i + 1) + "/" + jobs.size + ")\u2026")
                    val bmp = loader.bitmap(job, 2800)
                    if (bmp == null) {
                        results.add("")
                        continue
                    }
                    val text = try {
                        if (eng == 0) mlKitText(recognizer!!, bmp) else tessText(tess!!, bmp)
                    } catch (e: Exception) {
                        ""
                    }
                    bmp.recycle()
                    results.add(text.trim())
                    val snap = ArrayList(results)
                    runOnUiThread {
                        bar.progress = i + 1
                        showResults(snap, jobs.size)
                    }
                }
            } catch (e: Throwable) {
                if (err == null) err = e.message ?: "OCR failed"
            } finally {
                try {
                    tess?.recycle()
                    recognizer?.close()
                } catch (e: Exception) {
                    // ignore
                }
                loader.close()
            }
            val finalErr = err
            val snap = ArrayList(results)
            runOnUiThread {
                working = false
                edit.isEnabled = true
                progressRow.visibility = View.GONE
                showResults(snap, jobs.size)
                when {
                    finalErr != null -> toast(finalErr)
                    cancel -> toast("Stopped")
                    snap.all { it.isEmpty() } -> toast("No text found in this image")
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- actions
    private fun hasText(): Boolean {
        if (edit.text.toString().isBlank()) {
            toast("There is no text yet")
            return false
        }
        return true
    }

    private fun copy() {
        if (hasText()) Actions.copyText(this, "OCR", edit.text.toString())
    }

    private fun shareText() {
        if (!hasText()) return
        val i = android.content.Intent(android.content.Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(android.content.Intent.EXTRA_TEXT, edit.text.toString())
        startActivity(android.content.Intent.createChooser(i, "Share text"))
    }

    private fun writeUri(uri: Uri, bytes: ByteArray) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            toast("Saved")
        } catch (e: Exception) {
            toast("Could not save the file")
        }
    }
}
