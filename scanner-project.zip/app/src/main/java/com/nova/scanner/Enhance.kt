package com.nova.scanner

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

class EnhanceParams(
    var mode: Int = 0,
    var brightness: Int = 0,
    var contrast: Int = 0,
    var sharpen: Int = 30,
    var denoise: Int = 0,
    var shadow: Boolean = true,
    var upscale: Boolean = false
) {
    fun copy() = EnhanceParams(mode, brightness, contrast, sharpen, denoise, shadow, upscale)
}

/**
 * Document enhancement with classic image processing (no neural network, works offline):
 * shadow/background flattening, noise reduction, auto levels, adaptive black & white, sharpening.
 */
object Enhance {
    val modeNames = arrayOf("Auto", "Magic color", "Grayscale", "B&W document", "Faded text", "OCR-ready", "Manual only")

    private fun lum(c: Int): Int = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
    private fun clamp(v: Int): Int = if (v < 0) 0 else if (v > 255) 255 else v
    private fun pack(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b

    fun apply(src: Bitmap, p: EnhanceParams, maxLong: Int = 3200): Bitmap {
        var bmp = src
        val longest = max(src.width, src.height)
        val wantUp = p.upscale || (p.mode == 5 && longest < 1800)
        if (wantUp && longest * 2 <= maxLong) {
            bmp = Bitmap.createScaledBitmap(src, src.width * 2, src.height * 2, true)
        } else if (longest > maxLong) {
            val f = maxLong.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(src, max(1, (src.width * f).toInt()), max(1, (src.height * f).toInt()), true)
        }
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        if (bmp !== src) bmp.recycle()

        var mode = p.mode
        if (mode == 0) mode = if (meanSaturation(px) > 0.12f) 1 else 2
        if (p.denoise > 0) denoise(px, w, h, p.denoise)
        if (p.shadow && mode in 1..5) flatten(px, w, h)
        when (mode) {
            1 -> {
                levels(px, 0.004f, 0.996f)
                saturate(px, 1.12f)
            }
            2, 3, 5 -> {
                gray(px)
                levels(px, 0.01f, 0.99f)
            }
            4 -> {
                gray(px)
                levels(px, 0.02f, 0.97f)
                gamma(px, 1.7f)
            }
        }
        if (p.sharpen > 0) sharpen(px, w, h, p.sharpen)
        if (mode == 3 || mode == 5) threshold(px, w, h, if (mode == 3) 0.12f else 0.08f)
        if (p.brightness != 0 || p.contrast != 0) brightContrast(px, p.brightness, p.contrast)
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun meanSaturation(px: IntArray): Float {
        var sum = 0f
        var n = 0
        val step = max(1, px.size / 20000)
        var i = 0
        while (i < px.size) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            if (mx > 0) {
                sum += (mx - mn).toFloat() / mx
                n++
            }
            i += step
        }
        return if (n == 0) 0f else sum / n
    }

    private fun gray(px: IntArray) {
        for (i in px.indices) {
            val g = lum(px[i])
            px[i] = pack(g, g, g)
        }
    }

    private fun applyLut(px: IntArray, lut: IntArray) {
        for (i in px.indices) {
            val c = px[i]
            px[i] = pack(lut[(c shr 16) and 255], lut[(c shr 8) and 255], lut[c and 255])
        }
    }

    private fun levels(px: IntArray, loP: Float, hiP: Float) {
        val hist = IntArray(256)
        val step = max(1, px.size / 200000)
        var total = 0
        var i = 0
        while (i < px.size) {
            hist[lum(px[i])]++
            total++
            i += step
        }
        var acc = 0
        var lo = 0
        while (lo < 255 && acc + hist[lo] < total * loP) {
            acc += hist[lo]
            lo++
        }
        acc = 0
        var hi = 255
        while (hi > 0 && acc + hist[hi] < total * (1f - hiP)) {
            acc += hist[hi]
            hi--
        }
        if (hi - lo < 20) return
        val lut = IntArray(256) { clamp(((it - lo) * 255f / (hi - lo)).toInt()) }
        applyLut(px, lut)
    }

    private fun gamma(px: IntArray, g: Float) {
        val lut = IntArray(256) { clamp((255f * (it / 255f).pow(g)).toInt()) }
        applyLut(px, lut)
    }

    private fun brightContrast(px: IntArray, b: Int, c: Int) {
        val k = 1f + c / 100f
        val lut = IntArray(256) { clamp(((it - 128) * k + 128 + b * 1.28f).toInt()) }
        applyLut(px, lut)
    }

    private fun saturate(px: IntArray, k: Float) {
        for (i in px.indices) {
            val c = px[i]
            val g = lum(c)
            val r = (c shr 16) and 255
            val gg = (c shr 8) and 255
            val b = c and 255
            px[i] = pack(clamp((g + (r - g) * k).toInt()), clamp((g + (gg - g) * k).toInt()), clamp((g + (b - g) * k).toInt()))
        }
    }

    private fun sharpen(px: IntArray, w: Int, h: Int, amount: Int) {
        if (w < 3 || h < 3) return
        val a = amount / 100f * 0.9f
        val o = px.copyOf()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val c = o[i]
                val u = o[i - w]
                val d = o[i + w]
                val l = o[i - 1]
                val r = o[i + 1]
                val nr = ((c shr 16) and 255) * (1 + 4 * a) - a * (((u shr 16) and 255) + ((d shr 16) and 255) + ((l shr 16) and 255) + ((r shr 16) and 255))
                val ng = ((c shr 8) and 255) * (1 + 4 * a) - a * (((u shr 8) and 255) + ((d shr 8) and 255) + ((l shr 8) and 255) + ((r shr 8) and 255))
                val nb = (c and 255) * (1 + 4 * a) - a * ((u and 255) + (d and 255) + (l and 255) + (r and 255))
                px[i] = pack(clamp(nr.toInt()), clamp(ng.toInt()), clamp(nb.toInt()))
            }
        }
    }

    private fun denoise(px: IntArray, w: Int, h: Int, level: Int) {
        if (w < 3 || h < 3) return
        val thr = if (level == 1) 20 else 40
        val o = px.copyOf()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val lc = lum(o[i])
                var sr = 0
                var sg = 0
                var sb = 0
                var n = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val c = o[i + dy * w + dx]
                        val d = lum(c) - lc
                        if (d <= thr && d >= -thr) {
                            sr += (c shr 16) and 255
                            sg += (c shr 8) and 255
                            sb += c and 255
                            n++
                        }
                    }
                }
                px[i] = pack(sr / n, sg / n, sb / n)
            }
        }
    }

    /** Removes shadows / uneven lighting: divides by a smooth estimate of the paper colour. */
    private fun flatten(px: IntArray, w: Int, h: Int) {
        val f = max(1, max(w, h) / 200)
        val bw = (w + f - 1) / f
        val bh = (h + f - 1) / f
        val bg = Array(3) { IntArray(bw * bh) }
        val step = max(1, f / 4)
        for (by in 0 until bh) {
            for (bx in 0 until bw) {
                var mr = 0
                var mg = 0
                var mb = 0
                val y0 = by * f
                val y1 = min(h, y0 + f)
                val x0 = bx * f
                val x1 = min(w, x0 + f)
                var y = y0
                while (y < y1) {
                    var x = x0
                    while (x < x1) {
                        val c = px[y * w + x]
                        mr = max(mr, (c shr 16) and 255)
                        mg = max(mg, (c shr 8) and 255)
                        mb = max(mb, c and 255)
                        x += step
                    }
                    y += step
                }
                bg[0][by * bw + bx] = mr
                bg[1][by * bw + bx] = mg
                bg[2][by * bw + bx] = mb
            }
        }
        for (ch in 0..2) {
            boxBlur(bg[ch], bw, bh, 2)
            boxBlur(bg[ch], bw, bh, 2)
        }
        val xi0 = IntArray(w)
        val xi1 = IntArray(w)
        val wx = FloatArray(w)
        for (x in 0 until w) {
            val fx = (x + 0.5f) / f - 0.5f
            val i0 = fx.toInt().coerceIn(0, bw - 1)
            xi0[x] = i0
            xi1[x] = min(bw - 1, i0 + 1)
            wx[x] = (fx - i0).coerceIn(0f, 1f)
        }
        for (y in 0 until h) {
            val fy = (y + 0.5f) / f - 0.5f
            val j0 = fy.toInt().coerceIn(0, bh - 1)
            val j1 = min(bh - 1, j0 + 1)
            val wy = (fy - j0).coerceIn(0f, 1f)
            for (x in 0 until w) {
                val a = xi0[x]
                val b = xi1[x]
                val t = wx[x]
                val c = px[y * w + x]
                var out = 255 shl 24
                for (ch in 0..2) {
                    val arr = bg[ch]
                    val top = arr[j0 * bw + a] * (1 - t) + arr[j0 * bw + b] * t
                    val bot = arr[j1 * bw + a] * (1 - t) + arr[j1 * bw + b] * t
                    val g = max(90f, top * (1 - wy) + bot * wy)
                    val shift = 16 - 8 * ch
                    val v = clamp(((c shr shift and 255) * 255f / g).toInt())
                    out = out or (v shl shift)
                }
                px[y * w + x] = out
            }
        }
    }

    private fun boxBlur(a: IntArray, w: Int, h: Int, r: Int) {
        val t = IntArray(a.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0
                var n = 0
                for (k in max(0, x - r)..min(w - 1, x + r)) {
                    s += a[y * w + k]
                    n++
                }
                t[y * w + x] = s / n
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0
                var n = 0
                for (k in max(0, y - r)..min(h - 1, y + r)) {
                    s += t[k * w + x]
                    n++
                }
                a[y * w + x] = s / n
            }
        }
    }

    /** Adaptive (local mean) black & white, good for uneven documents. */
    private fun threshold(px: IntArray, w: Int, h: Int, t: Float) {
        val r = max(8, min(w, h) / 16)
        val tmp = IntArray(w * h)
        for (y in 0 until h) {
            var sum = 0
            var lo = 0
            var hi = -1
            for (x in 0 until w) {
                val nlo = max(0, x - r)
                val nhi = min(w - 1, x + r)
                while (hi < nhi) {
                    hi++
                    sum += px[y * w + hi] and 255
                }
                while (lo < nlo) {
                    sum -= px[y * w + lo] and 255
                    lo++
                }
                tmp[y * w + x] = sum
            }
        }
        for (x in 0 until w) {
            val nlox = max(0, x - r)
            val nhix = min(w - 1, x + r)
            val cx = nhix - nlox + 1
            var sum = 0
            var lo = 0
            var hi = -1
            for (y in 0 until h) {
                val nlo = max(0, y - r)
                val nhi = min(h - 1, y + r)
                while (hi < nhi) {
                    hi++
                    sum += tmp[hi * w + x]
                }
                while (lo < nlo) {
                    sum -= tmp[lo * w + x]
                    lo++
                }
                val mean = sum.toFloat() / (cx * (nhi - nlo + 1))
                val v = px[y * w + x] and 255
                val o = if (v < mean * (1f - t)) 0 else 255
                px[y * w + x] = pack(o, o, o)
            }
        }
    }
}
