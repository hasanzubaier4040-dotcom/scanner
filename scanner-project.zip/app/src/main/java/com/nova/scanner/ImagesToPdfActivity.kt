package com.nova.scanner

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Collections

class ImgItem(val uri: Uri, var rot: Int)

/** Pick images -> reorder / rotate / remove -> one PDF or separate PDFs. */
class ImagesToPdfActivity : AppCompatActivity() {

    private val items = ArrayList<ImgItem>()
    private lateinit var adapter: ImgAdapter
    private lateinit var info: TextView
    private lateinit var chipSize: TextView
    private lateinit var chipOrient: TextView
    private lateinit var chipMargin: TextView
    private lateinit var chipQuality: TextView
    private lateinit var chipOutput: TextView

    private val sizeNames = arrayOf("Image size (no margins)", "A4", "A5", "Letter", "Legal", "Custom\u2026")
    private val orientNames = arrayOf("Auto (by image)", "Portrait", "Landscape")
    private val marginNames = arrayOf("None", "Small", "Medium", "Large")
    private val marginPts = floatArrayOf(0f, 18f, 36f, 54f)
    private val outputNames = arrayOf("One PDF", "Separate PDFs")

    private var sizeIdx = 1
    private var orientIdx = 0
    private var marginIdx = 1
    private var outputIdx = 0
    private var customW = 210f // mm
    private var customH = 297f

    private val picker =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris.isNotEmpty()) {
                val start = items.size
                uris.forEach { items.add(ImgItem(it, 0)) }
                adapter.notifyItemRangeInserted(start, uris.size)
                updateInfo()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        picker.launch("image/*")
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val (header, _) = headerRow("Images \u2192 PDF") { finish() }
        header.addView(chip("\uFF0B Add") { picker.launch("image/*") })
        root.addView(header)

        info = TextView(this)
        info.setTextColor(GRAY)
        info.textSize = 12f
        info.setPadding(dp(18), 0, dp(18), dp(6))
        root.addView(info)

        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = ImgAdapter(items, { pos ->
            if (pos in items.indices) {
                items[pos].rot = (items[pos].rot + 90) % 360
                adapter.notifyItemChanged(pos)
            }
        }, { pos ->
            if (pos in items.indices) {
                items.removeAt(pos)
                adapter.notifyItemRemoved(pos)
                updateInfo()
            }
        })
        rv.adapter = adapter
        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val a = viewHolder.bindingAdapterPosition
                val b = target.bindingAdapterPosition
                if (a < 0 || b < 0) return false
                Collections.swap(items, a, b)
                adapter.notifyItemMoved(a, b)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touch.attachToRecyclerView(rv)
        root.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        chipSize = chip("") { chooseDialog("Page size", sizeNames, sizeIdx) { sizeSelected(it) } }
        chipOrient = chip("") {
            chooseDialog("Orientation", orientNames, orientIdx) {
                orientIdx = it
                refreshChips()
            }
        }
        chipMargin = chip("") {
            chooseDialog("Margins", marginNames, marginIdx) {
                marginIdx = it
                refreshChips()
            }
        }
        chipQuality = chip("") { Quality.showDialog(this) { refreshChips() } }
        chipOutput = chip("") {
            chooseDialog("Output", outputNames, outputIdx) {
                outputIdx = it
                refreshChips()
            }
        }
        root.addView(chipScroll(listOf(chipSize, chipOrient, chipMargin, chipQuality, chipOutput)))

        val create = bigButton("Create PDF", GREEN) { create() }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(dp(12), dp(2), dp(12), dp(12))
        root.addView(create, lp)
        setContentView(root)
        refreshChips()
        updateInfo()
    }

    private fun updateInfo() {
        info.text = if (items.isEmpty()) "No images yet. Tap \uFF0B Add."
        else "${items.size} image(s)  \u2022  long-press and drag to reorder, \u21BB to rotate"
    }

    private fun refreshChips() {
        chipSize.text = "\uD83D\uDCC4 " + (if (sizeIdx == 5) "Custom ${customW.toInt()}\u00D7${customH.toInt()} mm" else sizeNames[sizeIdx])
        chipOrient.text = "\u21C4 " + orientNames[orientIdx]
        chipMargin.text = "\u25A3 Margin: " + marginNames[marginIdx]
        chipQuality.text = "\u2699 Quality: " + Quality.summary(this)
        chipOutput.text = "\uD83D\uDCE6 " + outputNames[outputIdx]
    }

    private fun sizeSelected(i: Int) {
        if (i != 5) {
            sizeIdx = i
            refreshChips()
            return
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(4))
        val w = EditText(this)
        w.hint = "Width (mm)"
        w.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        w.setText(customW.toInt().toString())
        val h = EditText(this)
        h.hint = "Height (mm)"
        h.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        h.setText(customH.toInt().toString())
        box.addView(w)
        box.addView(h)
        AlertDialog.Builder(this)
            .setTitle("Custom page size")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val cw = w.text.toString().toFloatOrNull()
                val ch = h.text.toString().toFloatOrNull()
                if (cw != null && ch != null && cw >= 20f && ch >= 20f && cw <= 2000f && ch <= 2000f) {
                    customW = cw
                    customH = ch
                    sizeIdx = 5
                    refreshChips()
                } else {
                    toast("Enter sizes between 20 and 2000 mm")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun currentLayout(): PdfLayout {
        val mm = 72f / 25.4f
        val dims: Pair<Float, Float> = when (sizeIdx) {
            0 -> Pair(0f, 0f)
            1 -> Pair(595.28f, 841.89f)
            2 -> Pair(419.53f, 595.28f)
            3 -> Pair(612f, 792f)
            4 -> Pair(612f, 1008f)
            else -> Pair(customW * mm, customH * mm)
        }
        return PdfLayout(dims.first, dims.second, marginPts[marginIdx], orientIdx)
    }

    private fun create() {
        if (items.isEmpty()) {
            toast("Add some images first")
            return
        }
        val snapshot = items.map { Pair(it.uri, it.rot) }
        val lay = currentLayout()
        val separate = outputIdx == 1
        val resIdx = Quality.resIndex(this)
        runBusy("Creating PDF\u2026", { progress ->
            val budget = Quality.budgetPerPage(this, if (separate) 1 else snapshot.size)
            val created = ArrayList<Scan>()
            val encoded = ArrayList<EncodedPage>()
            snapshot.forEachIndexed { i, pr ->
                progress("Processing image ${i + 1}/${snapshot.size}\u2026")
                val e = Quality.encodeUri(this, pr.first, pr.second, resIdx, budget)
                if (e != null) {
                    if (separate) {
                        ScanStore.createFromPages(this, listOf(e), lay, null)?.let { created.add(it) }
                    } else {
                        encoded.add(e)
                    }
                }
            }
            if (!separate && encoded.isNotEmpty()) {
                progress("Building PDF\u2026")
                ScanStore.createFromPages(this, encoded, lay, null)?.let { created.add(it) }
            }
            created
        }, { res ->
            if (res == null || res.isEmpty()) {
                toast("Could not create the PDF")
            } else if (res.size == 1) {
                startActivity(Intent(this, DetailActivity::class.java).putExtra("id", res[0].id))
                finish()
            } else {
                toast("${res.size} PDFs created")
                startActivity(Intent(this, LibraryActivity::class.java))
                finish()
            }
        })
    }
}

class ImgAdapter(
    private val items: List<ImgItem>,
    private val onRotate: (Int) -> Unit,
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<ImgAdapter.VH>() {

    class VH(
        val root: LinearLayout,
        val thumb: ImageView,
        val label: TextView,
        val rotate: TextView,
        val remove: TextView
    ) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val root = LinearLayout(c)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(c.dp(12), c.dp(6), c.dp(8), c.dp(6))
        root.setBackgroundColor(BG)
        root.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
        val thumb = ImageView(c)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.setBackgroundColor(Color.parseColor("#262626"))
        root.addView(thumb, LinearLayout.LayoutParams(c.dp(62), c.dp(78)))
        val label = TextView(c)
        label.setTextColor(Color.WHITE)
        label.textSize = 15f
        label.setPadding(c.dp(14), 0, 0, 0)
        root.addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
        val rotate = c.iconBtn("\u21BB") {}
        val remove = c.iconBtn("\u2715") {}
        root.addView(rotate)
        root.addView(remove)
        return VH(root, thumb, label, rotate, remove)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.label.text = "Image " + (position + 1) + (if (item.rot != 0) "   (rotated ${item.rot}\u00B0)" else "")
        Thumbs.load(h.root.context, item.uri, item.rot, h.thumb, 300)
        h.rotate.setOnClickListener { onRotate(h.bindingAdapterPosition) }
        h.remove.setOnClickListener { onRemove(h.bindingAdapterPosition) }
    }
}
