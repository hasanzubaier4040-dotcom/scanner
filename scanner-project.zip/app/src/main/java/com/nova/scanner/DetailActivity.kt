package com.nova.scanner

import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class DetailActivity : AppCompatActivity() {

    private var scan: Scan? = null
    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var rv: RecyclerView
    private lateinit var qualityChip: TextView

    private val savePdfLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
            val s = scan
            if (uri != null && s != null) {
                runBusy("Saving PDF\u2026", { p ->
                    val f = Exporter.pdf(this, s, p)
                    if (f != null) {
                        contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                        true
                    } else {
                        null
                    }
                }, { ok -> toast(if (ok == true) "PDF saved" else "Could not save PDF") })
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scan = ScanStore.find(this, intent.getLongExtra("id", -1L))
        if (scan == null) {
            finish()
            return
        }
        buildUi()
        bind()
    }

    override fun onResume() {
        super.onResume()
        scan?.let { s ->
            val fresh = ScanStore.find(this, s.id)
            if (fresh == null) {
                finish()
            } else {
                scan = fresh
                if (::titleView.isInitialized) bind()
            }
        }
    }

    private fun weight(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.setMargins(dp(4), 0, dp(4), 0)
        return lp
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val (header, tv) = headerRow("") { finish() }
        titleView = tv
        header.addView(iconBtn("\u270E") { scan?.let { s -> Actions.rename(this, s) { reload() } } })
        header.addView(iconBtn("\uD83D\uDDD1") { scan?.let { s -> Actions.delete(this, s) { finish() } } })
        root.addView(header)

        subView = TextView(this)
        subView.setTextColor(GRAY)
        subView.textSize = 12f
        subView.setPadding(dp(18), 0, dp(18), dp(6))
        root.addView(subView)

        rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        root.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        qualityChip = chip("") {
            Quality.showDialog(this) { updateQualityChip() }
        }
        val tools = chipScroll(listOf(
            qualityChip,
            chip("\uD83D\uDD24 OCR text") {
                scan?.let { startActivity(Intent(this, OcrActivity::class.java).putExtra("id", it.id)) }
            },
            chip("\u25A6 Scan QR") {
                scan?.let { startActivity(Intent(this, QrActivity::class.java).putExtra("id", it.id)) }
            },
            chip("\uD83D\uDCC1 Move") { scan?.let { s -> Actions.move(this, s) { reload() } } }
        ))
        root.addView(tools)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(8), dp(2), dp(8), dp(10))
        bar.addView(bigButton("\uD83D\uDCE4 Share", GREEN) { scan?.let { Actions.shareDialog(this, it) } }, weight())
        bar.addView(bigButton("\uD83D\uDCBE Save PDF", BLUE) { savePdf() }, weight())
        bar.addView(bigButton("\uD83D\uDDBC Save images", PURPLE) { saveImages() }, weight())
        root.addView(bar)

        setContentView(root)
        updateQualityChip()
    }

    private fun updateQualityChip() {
        qualityChip.text = "\u2699 Quality: " + Quality.summary(this)
    }

    private fun reload() {
        scan = scan?.let { ScanStore.find(this, it.id) }
        bind()
    }

    private fun bind() {
        val s = scan ?: return
        titleView.text = s.name
        val n = s.pages.size
        subView.text = "$n page" + (if (n == 1) "" else "s") + "  \u2022  " + fmtSize(s.sizeBytes) +
            "  \u2022  " + fmtDate(s.id) + (if (s.folder.isNotEmpty()) "  \u2022  \uD83D\uDCC1 " + s.folder else "")
        rv.adapter = PageAdapter(s.pages)
    }

    private fun savePdf() {
        val s = scan ?: return
        if (s.pdf == null && s.pages.isEmpty()) {
            toast("No PDF found")
            return
        }
        savePdfLauncher.launch(safeName(s.name) + ".pdf")
    }

    private fun saveImages() {
        val s = scan ?: return
        if (Build.VERSION.SDK_INT < 29) {
            toast("On this Android version use Share \u2192 Images \u2192 Save to Gallery")
            return
        }
        runBusy("Saving images\u2026", { p ->
            val files: List<File> = Exporter.images(this, s, p)
            var n = 0
            for (f in files) {
                try {
                    val cv = ContentValues()
                    cv.put(MediaStore.Images.Media.DISPLAY_NAME, f.name)
                    cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NovaScanner")
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                        n++
                    }
                } catch (e: Exception) {
                    // skip this image
                }
            }
            n
        }, { n -> toast((n ?: 0).toString() + " image(s) saved to Pictures/NovaScanner") })
    }
}

class PageAdapter(private val pages: List<File>) : RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(val iv: ImageView) : RecyclerView.ViewHolder(iv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val iv = ImageView(c)
        iv.adjustViewBounds = true
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setBackgroundColor(Color.parseColor("#1E1E1E"))
        iv.minimumHeight = c.dp(320)
        val lp = RecyclerView.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = c.dp(10)
        iv.layoutParams = lp
        return VH(iv)
    }

    override fun getItemCount(): Int = pages.size

    override fun onBindViewHolder(h: VH, position: Int) {
        Thumbs.load(h.iv.context, pages[position], h.iv, 1600)
    }
}
