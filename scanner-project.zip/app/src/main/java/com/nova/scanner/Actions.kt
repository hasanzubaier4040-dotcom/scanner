package com.nova.scanner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

object Actions {

    fun uriFor(a: AppCompatActivity, f: File): Uri =
        FileProvider.getUriForFile(a, a.packageName + ".fileprovider", f)

    fun copyText(a: AppCompatActivity, label: String, text: String) {
        val cm = a.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        a.toast("Copied")
    }

    fun shareDialog(a: AppCompatActivity, s: Scan) {
        AlertDialog.Builder(a)
            .setTitle("Share as  (" + Quality.summary(a) + ")")
            .setItems(arrayOf("PDF  (best for WhatsApp / Email)", "Images (JPG)")) { _, i ->
                if (i == 0) sharePdf(a, s) else shareImages(a, s)
            }
            .show()
    }

    fun sharePdf(a: AppCompatActivity, s: Scan) {
        a.runBusy("Preparing PDF\u2026", { p -> Exporter.pdf(a, s, p) }, { f ->
            if (f == null) {
                a.toast("Could not prepare the PDF")
            } else {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "application/pdf"
                i.putExtra(Intent.EXTRA_STREAM, uriFor(a, f))
                i.putExtra(Intent.EXTRA_SUBJECT, s.name)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                a.startActivity(Intent.createChooser(i, "Share PDF"))
            }
        })
    }

    fun shareImages(a: AppCompatActivity, s: Scan) {
        a.runBusy("Preparing images\u2026", { p -> Exporter.images(a, s, p) }, { files ->
            if (files == null || files.isEmpty()) {
                a.toast("No images to share")
            } else {
                val uris = ArrayList<Uri>(files.map { uriFor(a, it) })
                val i: Intent
                if (uris.size == 1) {
                    i = Intent(Intent.ACTION_SEND)
                    i.putExtra(Intent.EXTRA_STREAM, uris[0])
                } else {
                    i = Intent(Intent.ACTION_SEND_MULTIPLE)
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
                i.type = "image/jpeg"
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                a.startActivity(Intent.createChooser(i, "Share images"))
            }
        })
    }

    private fun input(a: AppCompatActivity, title: String, initial: String, ok: String, onText: (String) -> Unit) {
        val et = EditText(a)
        et.setText(initial)
        et.setSelection(et.text.length)
        et.setPadding(a.dp(20), a.dp(16), a.dp(20), a.dp(8))
        AlertDialog.Builder(a)
            .setTitle(title)
            .setView(et)
            .setPositiveButton(ok) { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) onText(n)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun rename(a: AppCompatActivity, s: Scan, onDone: () -> Unit) {
        input(a, "Rename", s.name, "Save") {
            ScanStore.rename(s, it)
            onDone()
        }
    }

    fun newFolder(a: AppCompatActivity, onCreated: (String) -> Unit) {
        input(a, "New folder", "", "Create") {
            Folders.add(a, it)
            onCreated(it)
        }
    }

    fun renameFolder(a: AppCompatActivity, old: String, onDone: () -> Unit) {
        input(a, "Rename folder", old, "Save") {
            Folders.rename(a, old, it)
            onDone()
        }
    }

    fun deleteFolder(a: AppCompatActivity, name: String, onDone: () -> Unit) {
        AlertDialog.Builder(a)
            .setTitle("Delete folder \"$name\"?")
            .setMessage("Documents inside will be moved out, not deleted.")
            .setPositiveButton("Delete") { _, _ ->
                Folders.remove(a, name)
                onDone()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun move(a: AppCompatActivity, s: Scan, onDone: () -> Unit) {
        val folders = Folders.list(a)
        val labels = ArrayList<String>()
        labels.add("(No folder)")
        folders.forEach { labels.add("\uD83D\uDCC1 $it") }
        labels.add("\uFF0B New folder\u2026")
        AlertDialog.Builder(a)
            .setTitle("Move to")
            .setItems(labels.toTypedArray()) { _, i ->
                when {
                    i == 0 -> {
                        ScanStore.move(s, "")
                        onDone()
                    }
                    i == labels.size - 1 -> newFolder(a) { name ->
                        ScanStore.move(s, name)
                        onDone()
                    }
                    else -> {
                        ScanStore.move(s, folders[i - 1])
                        onDone()
                    }
                }
            }
            .show()
    }

    fun delete(a: AppCompatActivity, s: Scan, onDone: () -> Unit) {
        AlertDialog.Builder(a)
            .setTitle("Delete this document?")
            .setMessage(s.name)
            .setPositiveButton("Delete") { _, _ ->
                ScanStore.delete(s)
                onDone()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
