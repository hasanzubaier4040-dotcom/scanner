package com.nova.scanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ===================================================================== page flow helper
class PdfFlow(val pw: Int, val ph: Int, val margin: Float) {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    var canvas: Canvas? = null
    var y = margin
    private var pageNo = 0
    val contentW: Float get() = pw - 2 * margin

    fun newPage() {
        page?.let { doc.finishPage(it) }
        pageNo++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
        page = p
        canvas = p.canvas
        y = margin
    }

    fun ensure(h: Float) {
        if (page == null) newPage()
        if (y + h > ph - margin && y > margin + 1f) newPage()
    }

    fun drawLayout(layout: StaticLayout, x: Float) {
        if (page == null) newPage()
        var start = 0
        while (start < layout.lineCount) {
            val avail = ph - margin - y
            val top = layout.getLineTop(start)
            var end = start
            while (end < layout.lineCount && layout.getLineBottom(end) - top <= avail) end++
            if (end == start) {
                if (y > margin + 1f) {
                    newPage()
                    continue
                }
                end = start + 1
            }
            val c = canvas!!
            c.save()
            c.translate(x, y - top)
            c.clipRect(0f, top.toFloat(), layout.width.toFloat(), layout.getLineBottom(end - 1).toFloat())
            layout.draw(c)
            c.restore()
            y += layout.getLineBottom(end - 1) - top
            start = end
            if (start < layout.lineCount) newPage()
        }
    }

    fun drawBitmap(b: Bitmap, w: Float, h: Float, x: Float) {
        ensure(h)
        canvas!!.drawBitmap(b, null, android.graphics.RectF(x, y, x + w, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
        y += h
    }

    fun finish(out: File): Boolean {
        return try {
            if (pageNo == 0) newPage()
            page?.let { doc.finishPage(it) }
            FileOutputStream(out).use { doc.writeTo(it) }
            true
        } catch (e: Exception) {
            false
        } finally {
            doc.close()
        }
    }
}

// ===================================================================== DOCX -> PDF
class DRun(val text: String, val bold: Boolean, val italic: Boolean, val size: Float, val color: Int, val underline: Boolean)
class DPara(
    val runs: List<DRun>, val align: Int, val heading: Int, val list: Boolean,
    val pageBreakBefore: Boolean, val images: List<ByteArray>
)

sealed class DBlock {
    class P(val p: DPara) : DBlock()
    class T(val rows: List<List<List<DPara>>>) : DBlock()
    object Break : DBlock()
}

object DocxReader {
    private fun flag(v: String?): Boolean = v == null || (v != "0" && v != "false" && v != "none")

    fun read(file: File): List<DBlock> {
        val zf = ZipFile(file)
        try {
            val rels = HashMap<String, String>()
            zf.getEntry("word/_rels/document.xml.rels")?.let { e ->
                val p = Xml.newPullParser()
                p.setInput(zf.getInputStream(e), "UTF-8")
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                        val id = p.getAttributeValue(null, "Id")
                        val t = p.getAttributeValue(null, "Target")
                        if (id != null && t != null) rels[id] = t
                    }
                    ev = p.next()
                }
            }
            val docEntry = zf.getEntry("word/document.xml") ?: throw IllegalStateException("Not a .docx file")
            val p = Xml.newPullParser()
            p.setInput(zf.getInputStream(docEntry), "UTF-8")

            val blocks = ArrayList<DBlock>()
            var tblDepth = 0
            var rows: ArrayList<List<List<DPara>>>? = null
            var curRow: ArrayList<List<DPara>>? = null
            var curCell: ArrayList<DPara>? = null
            var runs = ArrayList<DRun>()
            var imgs = ArrayList<ByteArray>()
            var align = 0
            var heading = 0
            var isList = false
            var pbBefore = false
            var brkAfter = false
            var inPPr = false
            var inRPr = false
            var inRun = false
            var inT = false
            var rb = false
            var ri = false
            var ru = false
            var rsz = 0f
            var rcol = Color.BLACK
            val rtext = StringBuilder()

            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "w:tbl" -> {
                            tblDepth++
                            if (tblDepth == 1) rows = ArrayList()
                        }
                        "w:tr" -> if (tblDepth == 1) curRow = ArrayList()
                        "w:tc" -> if (tblDepth == 1) curCell = ArrayList()
                        "w:p" -> {
                            runs = ArrayList()
                            imgs = ArrayList()
                            align = 0
                            heading = 0
                            isList = false
                            pbBefore = false
                            brkAfter = false
                        }
                        "w:pPr" -> inPPr = true
                        "w:jc" -> if (inPPr) {
                            val v = p.getAttributeValue(null, "w:val")
                            align = when (v) {
                                "center" -> 1
                                "right", "end" -> 2
                                else -> 0
                            }
                        }
                        "w:pStyle" -> if (inPPr) {
                            val v = (p.getAttributeValue(null, "w:val") ?: "").lowercase()
                            heading = when {
                                v == "title" -> 1
                                v.startsWith("heading") -> (v.removePrefix("heading").toIntOrNull() ?: 2).coerceIn(1, 3)
                                else -> 0
                            }
                        }
                        "w:numPr" -> if (inPPr) isList = true
                        "w:pageBreakBefore" -> if (inPPr) pbBefore = true
                        "w:r" -> {
                            inRun = true
                            rb = false
                            ri = false
                            ru = false
                            rsz = 0f
                            rcol = Color.BLACK
                            rtext.setLength(0)
                        }
                        "w:rPr" -> inRPr = true
                        "w:b" -> if (inRun && inRPr) rb = flag(p.getAttributeValue(null, "w:val"))
                        "w:i" -> if (inRun && inRPr) ri = flag(p.getAttributeValue(null, "w:val"))
                        "w:u" -> if (inRun && inRPr) ru = flag(p.getAttributeValue(null, "w:val"))
                        "w:sz" -> if (inRun && inRPr) rsz = (p.getAttributeValue(null, "w:val")?.toFloatOrNull() ?: 22f) / 2f
                        "w:color" -> if (inRun && inRPr) {
                            val v = p.getAttributeValue(null, "w:val")
                            rcol = try {
                                if (v == null || v == "auto") Color.BLACK else Color.parseColor("#" + v)
                            } catch (e: Exception) {
                                Color.BLACK
                            }
                        }
                        "w:t" -> inT = true
                        "w:tab" -> if (inRun) rtext.append("    ")
                        "w:br" -> if (inRun) {
                            if (p.getAttributeValue(null, "w:type") == "page") brkAfter = true else rtext.append("\n")
                        }
                        "a:blip" -> {
                            val id = p.getAttributeValue(null, "r:embed")
                            val target = if (id != null) rels[id] else null
                            if (target != null) {
                                val name = if (target.startsWith("/")) target.substring(1) else "word/$target"
                                zf.getEntry(name)?.let { ie -> imgs.add(zf.getInputStream(ie).use { it.readBytes() }) }
                            }
                        }
                    }
                    XmlPullParser.TEXT -> if (inT) rtext.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) {
                        "w:t" -> inT = false
                        "w:rPr" -> inRPr = false
                        "w:pPr" -> inPPr = false
                        "w:r" -> {
                            if (rtext.isNotEmpty()) {
                                val baseSize = when (heading) {
                                    1 -> 20f
                                    2 -> 16f
                                    3 -> 14f
                                    else -> 11f
                                }
                                runs.add(DRun(rtext.toString(), rb || heading > 0, ri, if (rsz > 0f) rsz else baseSize, rcol, ru))
                            }
                            inRun = false
                        }
                        "w:p" -> {
                            val para = DPara(runs, align, heading, isList, pbBefore, imgs)
                            val cell = curCell
                            if (cell != null) cell.add(para) else blocks.add(DBlock.P(para))
                            if (brkAfter) blocks.add(DBlock.Break)
                        }
                        "w:tc" -> if (tblDepth == 1) {
                            curRow?.add(curCell ?: ArrayList())
                            curCell = null
                        }
                        "w:tr" -> if (tblDepth == 1) {
                            curRow?.let { rows?.add(it) }
                            curRow = null
                        }
                        "w:tbl" -> {
                            if (tblDepth == 1) {
                                rows?.let { blocks.add(DBlock.T(it)) }
                                rows = null
                            }
                            tblDepth--
                        }
                    }
                }
                ev = p.next()
            }
            return blocks
        } finally {
            zf.close()
        }
    }
}

object DocxPdf {
    private fun spannable(paras: List<DPara>): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        paras.forEachIndexed { pi, p ->
            if (pi > 0) sb.append("\n")
            if (p.list) sb.append("\u2022  ")
            for (r in p.runs) {
                val s = sb.length
                sb.append(r.text)
                val e = sb.length
                if (e > s) {
                    val st = if (r.bold && r.italic) Typeface.BOLD_ITALIC else if (r.bold) Typeface.BOLD else if (r.italic) Typeface.ITALIC else Typeface.NORMAL
                    if (st != Typeface.NORMAL) sb.setSpan(StyleSpan(st), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(AbsoluteSizeSpan(max(6, r.size.roundToInt())), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    if (r.color != Color.BLACK) sb.setSpan(ForegroundColorSpan(r.color), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    if (r.underline) sb.setSpan(UnderlineSpan(), s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }
        if (sb.isEmpty()) sb.append(" ")
        return sb
    }

    private fun layout(text: CharSequence, width: Int, align: Int): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = 11f
        tp.color = Color.BLACK
        val a = when (align) {
            1 -> Layout.Alignment.ALIGN_CENTER
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, max(20, width)).setAlignment(a).setLineSpacing(2f, 1f).build()
    }

    fun render(docx: File, out: File): Boolean {
        return try {
            val blocks = DocxReader.read(docx)
            val flow = PdfFlow(595, 842, 56f)
            val cw = flow.contentW.toInt()
            for (b in blocks) {
                when (b) {
                    is DBlock.Break -> flow.newPage()
                    is DBlock.P -> {
                        val p = b.p
                        if (p.pageBreakBefore) flow.newPage()
                        val indent = if (p.list) 14f else 0f
                        val l = layout(spannable(listOf(p)), cw - indent.toInt(), p.align)
                        flow.drawLayout(l, flow.margin + indent)
                        for (img in p.images) {
                            val bmp = BitmapFactory.decodeByteArray(img, 0, img.size) ?: continue
                            val w = min(flow.contentW, bmp.width.toFloat())
                            val h = min(w * bmp.height / bmp.width, 640f)
                            flow.drawBitmap(bmp, h * bmp.width / bmp.height, h, flow.margin)
                            bmp.recycle()
                        }
                        flow.y += 6f
                    }
                    is DBlock.T -> {
                        val cols = b.rows.maxOfOrNull { it.size } ?: 0
                        if (cols > 0) {
                            val colW = flow.contentW / cols
                            val line = Paint()
                            line.style = Paint.Style.STROKE
                            line.color = Color.GRAY
                            line.strokeWidth = 0.6f
                            for (row in b.rows) {
                                val ls = (0 until cols).map { c ->
                                    val paras = row.getOrNull(c) ?: emptyList()
                                    layout(spannable(paras), (colW - 8f).toInt(), 0)
                                }
                                val rowH = (ls.maxOfOrNull { it.height } ?: 14) + 8f
                                flow.ensure(rowH)
                                val c = flow.canvas!!
                                for (ci in 0 until cols) {
                                    val x = flow.margin + ci * colW
                                    c.drawRect(x, flow.y, x + colW, flow.y + rowH, line)
                                    c.save()
                                    c.translate(x + 4f, flow.y + 4f)
                                    c.clipRect(0f, 0f, colW - 8f, rowH - 8f)
                                    ls[ci].draw(c)
                                    c.restore()
                                }
                                flow.y += rowH
                            }
                            flow.y += 8f
                        }
                    }
                }
            }
            flow.finish(out)
        } catch (e: Exception) {
            false
        }
    }
}

// ===================================================================== XLSX -> PDF
class XSheet(val name: String, val cells: Map<Int, Map<Int, String>>, val colW: Map<Int, Float>, val maxCol: Int)

object XlsxReader {
    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break
        }
        return n - 1
    }

    private fun rowIndex(ref: String): Int = ref.dropWhile { it in 'A'..'Z' }.toIntOrNull()?.minus(1) ?: 0

    private fun isDateFmt(id: Int, code: String?): Boolean {
        if (id in 14..22 || id in 45..47) return true
        if (code == null) return false
        val c = code.lowercase().replace(Regex("\"[^\"]*\""), "")
        return c.contains("yy") || c.contains("dd") || c.contains("hh") || (c.contains("mm") && c.contains("d"))
    }

    private fun fmtNumber(v: String, date: Boolean): String {
        val d = v.toDoubleOrNull() ?: return v
        if (date) {
            val cal = Calendar.getInstance()
            cal.clear()
            cal.set(1899, Calendar.DECEMBER, 30, 0, 0, 0)
            cal.add(Calendar.DAY_OF_YEAR, d.toInt())
            val frac = d - d.toInt()
            val y = cal.get(Calendar.YEAR)
            val m = cal.get(Calendar.MONTH) + 1
            val day = cal.get(Calendar.DAY_OF_MONTH)
            val base = String.format("%02d-%02d-%04d", day, m, y)
            if (frac > 0.0001) {
                val secs = (frac * 86400).roundToInt()
                return base + String.format(" %02d:%02d", secs / 3600, (secs % 3600) / 60)
            }
            return base
        }
        if (d == d.toLong().toDouble() && kotlin.math.abs(d) < 1e15) return d.toLong().toString()
        return String.format("%.6g", d).trimEnd('0').trimEnd('.')
    }

    fun read(file: File): List<XSheet> {
        val zf = ZipFile(file)
        try {
            // shared strings
            val shared = ArrayList<String>()
            zf.getEntry("xl/sharedStrings.xml")?.let { e ->
                val p = Xml.newPullParser()
                p.setInput(zf.getInputStream(e), "UTF-8")
                var ev = p.eventType
                var sb: StringBuilder? = null
                var inT = false
                while (ev != XmlPullParser.END_DOCUMENT) {
                    when (ev) {
                        XmlPullParser.START_TAG -> if (p.name == "si") sb = StringBuilder() else if (p.name == "t") inT = true
                        XmlPullParser.TEXT -> if (inT) sb?.append(p.text)
                        XmlPullParser.END_TAG -> if (p.name == "t") inT = false else if (p.name == "si") {
                            shared.add(sb?.toString() ?: "")
                            sb = null
                        }
                    }
                    ev = p.next()
                }
            }
            // date styles
            val dateXf = ArrayList<Boolean>()
            zf.getEntry("xl/styles.xml")?.let { e ->
                val p = Xml.newPullParser()
                p.setInput(zf.getInputStream(e), "UTF-8")
                val codes = HashMap<Int, String>()
                var inXfs = false
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "numFmt" -> {
                                val id = p.getAttributeValue(null, "numFmtId")?.toIntOrNull()
                                val code = p.getAttributeValue(null, "formatCode")
                                if (id != null && code != null) codes[id] = code
                            }
                            "cellXfs" -> inXfs = true
                            "xf" -> if (inXfs) {
                                val id = p.getAttributeValue(null, "numFmtId")?.toIntOrNull() ?: 0
                                dateXf.add(isDateFmt(id, codes[id]))
                            }
                        }
                    } else if (ev == XmlPullParser.END_TAG && p.name == "cellXfs") {
                        inXfs = false
                    }
                    ev = p.next()
                }
            }
            // workbook: sheet names + files
            val relMap = HashMap<String, String>()
            zf.getEntry("xl/_rels/workbook.xml.rels")?.let { e ->
                val p = Xml.newPullParser()
                p.setInput(zf.getInputStream(e), "UTF-8")
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                        val id = p.getAttributeValue(null, "Id")
                        val t = p.getAttributeValue(null, "Target")
                        if (id != null && t != null) relMap[id] = if (t.startsWith("/")) t.substring(1) else "xl/$t"
                    }
                    ev = p.next()
                }
            }
            val sheetsMeta = ArrayList<Pair<String, String>>()
            val wb = zf.getEntry("xl/workbook.xml") ?: throw IllegalStateException("Not an .xlsx file")
            run {
                val p = Xml.newPullParser()
                p.setInput(zf.getInputStream(wb), "UTF-8")
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                        val name = p.getAttributeValue(null, "name") ?: "Sheet"
                        val rid = p.getAttributeValue(null, "r:id")
                        val path = if (rid != null) relMap[rid] else null
                        if (path != null) sheetsMeta.add(Pair(name, path))
                    }
                    ev = p.next()
                }
            }
            val out = ArrayList<XSheet>()
            for ((name, path) in sheetsMeta) {
                val e = zf.getEntry(path) ?: continue
                val cells = HashMap<Int, HashMap<Int, String>>()
                val colW = HashMap<Int, Float>()
                var maxCol = 0
                val p = Xml.newPullParser()
                p.setInput(zf.getInputStream(e), "UTF-8")
                var ev = p.eventType
                var ref = ""
                var type = ""
                var style = 0
                var inV = false
                var inIs = false
                var inT = false
                val vb = StringBuilder()
                while (ev != XmlPullParser.END_DOCUMENT) {
                    when (ev) {
                        XmlPullParser.START_TAG -> when (p.name) {
                            "col" -> {
                                val mn = p.getAttributeValue(null, "min")?.toIntOrNull()
                                val mx = p.getAttributeValue(null, "max")?.toIntOrNull()
                                val w = p.getAttributeValue(null, "width")?.toFloatOrNull()
                                if (mn != null && mx != null && w != null) for (c in mn..min(mx, mn + 200)) colW[c - 1] = w
                            }
                            "c" -> {
                                ref = p.getAttributeValue(null, "r") ?: ""
                                type = p.getAttributeValue(null, "t") ?: ""
                                style = p.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                                vb.setLength(0)
                            }
                            "v" -> inV = true
                            "is" -> inIs = true
                            "t" -> if (inIs) inT = true
                        }
                        XmlPullParser.TEXT -> if (inV || inT) vb.append(p.text)
                        XmlPullParser.END_TAG -> when (p.name) {
                            "v" -> inV = false
                            "t" -> inT = false
                            "is" -> inIs = false
                            "c" -> {
                                val raw = vb.toString()
                                val text = when (type) {
                                    "s" -> shared.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: ""
                                    "inlineStr", "str" -> raw
                                    "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"
                                    "e" -> raw
                                    else -> if (raw.isBlank()) "" else fmtNumber(raw.trim(), dateXf.getOrNull(style) == true)
                                }
                                if (text.isNotEmpty() && ref.isNotEmpty()) {
                                    val ci = colIndex(ref)
                                    val ri = rowIndex(ref)
                                    cells.getOrPut(ri) { HashMap() }[ci] = text
                                    if (ci > maxCol) maxCol = ci
                                }
                            }
                        }
                    }
                    ev = p.next()
                }
                out.add(XSheet(name, cells, colW, maxCol))
            }
            return out
        } finally {
            zf.close()
        }
    }
}

object XlsxPdf {
    fun render(xlsx: File, out: File): Boolean {
        return try {
            val sheets = XlsxReader.read(xlsx)
            if (sheets.isEmpty()) return false
            // landscape if any sheet is wide
            val wide = sheets.any { s -> (0..s.maxCol).sumOf { (s.colW[it] ?: 8.43f).toDouble() * 5.5 + 5 } > 520 }
            val flow = if (wide) PdfFlow(842, 595, 30f) else PdfFlow(595, 842, 36f)
            for ((si, s) in sheets.withIndex()) {
                if (si > 0) flow.newPage()
                val tp0 = TextPaint(Paint.ANTI_ALIAS_FLAG)
                tp0.textSize = 13f
                tp0.typeface = Typeface.DEFAULT_BOLD
                tp0.color = Color.BLACK
                val head = StaticLayout.Builder.obtain(s.name, 0, s.name.length, tp0, flow.contentW.toInt()).build()
                flow.drawLayout(head, flow.margin)
                flow.y += 6f
                val widths = (0..s.maxCol).map { (s.colW[it] ?: 8.43f) * 5.5f + 5f }
                val total = widths.sum()
                val scale = min(1f, flow.contentW / total).coerceAtLeast(0.45f)
                val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
                tp.textSize = max(5f, 9f * scale)
                tp.color = Color.BLACK
                val grid = Paint()
                grid.style = Paint.Style.STROKE
                grid.color = Color.LTGRAY
                grid.strokeWidth = 0.5f
                for (r in s.cells.keys.sorted()) {
                    val row = s.cells[r] ?: continue
                    val ls = HashMap<Int, StaticLayout>()
                    var rowH = 12f
                    for ((c, text) in row) {
                        val w = (widths.getOrNull(c) ?: 50f) * scale
                        val l = StaticLayout.Builder.obtain(text, 0, min(text.length, 400), tp, max(10, (w - 4f).toInt())).build()
                        ls[c] = l
                        rowH = max(rowH, l.height + 4f)
                    }
                    flow.ensure(rowH)
                    val cv = flow.canvas!!
                    var x = flow.margin
                    for (c in 0..s.maxCol) {
                        val w = widths[c] * scale
                        if (x + w > flow.pw - flow.margin + 1f) break
                        cv.drawRect(x, flow.y, x + w, flow.y + rowH, grid)
                        val l = ls[c]
                        if (l != null) {
                            cv.save()
                            cv.translate(x + 2f, flow.y + 2f)
                            cv.clipRect(0f, 0f, w - 4f, rowH - 4f)
                            l.draw(cv)
                            cv.restore()
                        }
                        x += w
                    }
                    flow.y += rowH
                }
            }
            flow.finish(out)
        } catch (e: Exception) {
            false
        }
    }
}
